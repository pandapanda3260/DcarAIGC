"""Manual publishing labels and atomic account pause/resume operations.

Publishing frequency is an operator label, never a provider scheduling rule.
The existing main-database operator receipts persist labels without a DDL change.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping
from uuid import uuid4

from .account_operating_receipts import (
    AccountOperatingStatusError as AccountOperatingStatusError,
    find_status_request,
    load_update_frequencies,
    record_status_receipt,
    validate_status_request_id,
)
from .account_states import set_account_enabled_in_transaction
from .system_roster import current_system_members, remove_system_member, upsert_system_members


ACCOUNT_STATUSES = frozenset({"daily", "weekly", "paused"})
ScheduleActivation = Callable[
    [sqlite3.Connection, Mapping[str, Any]], Mapping[str, Any]
]


def account_operating_status(account: Mapping[str, Any]) -> str:
    """Project an account with its optional verified operator frequency."""

    value = dict(account)
    if not bool(value["enabled"]):
        return "paused"
    frequency = value.get("update_frequency")
    return str(frequency) if frequency in {"daily", "weekly"} else "unmarked"


def _resume_member(
    connection: sqlite3.Connection, identity: Mapping[str, Any]
) -> dict[str, Any]:
    previous = connection.execute(
        """SELECT m.* FROM account_roster_members m
           JOIN account_roster_snapshots s ON s.id=m.snapshot_id
           WHERE m.account_identity_id=? AND s.source_family='system'
           ORDER BY s.source_captured_at DESC,s.id DESC LIMIT 1""",
        (identity["id"],),
    ).fetchone()
    historical = dict(previous) if previous is not None else {}
    metadata = json.loads(historical.get("metadata_json", "{}"))
    return {
        "platform": identity["platform"],
        "uid": identity["uid"],
        "nickname": metadata.get("nickname") or identity["nickname"],
        "profile_ref": historical.get("profile_ref"),
        "monitoring_status": historical.get("monitoring_status", "unknown"),
        "authorization_status": historical.get("authorization_status", "unknown"),
        "monitoring_started_at": historical.get("monitoring_started_at"),
        "metadata": metadata,
    }


def update_account_operating_status_in_transaction(
    connection: sqlite3.Connection,
    account_id: int,
    value: Mapping[str, Any],
    *,
    raw_root: Path,
    actor: str,
    reason: str,
    activation_id: int | None = None,
    schedule_activation: ScheduleActivation | None = None,
) -> dict[str, Any]:
    """Apply operating edits, state event and next-roster change as one unit.

    The caller owns the transaction. The savepoint also rolls back local edits
    when the caller catches an activation failure and continues its transaction.
    """

    from .operations import update_account_in_transaction

    if not connection.in_transaction:
        raise AccountOperatingStatusError(
            "account_status_transaction_required", "账号状态更新需要已有事务"
        )
    supplied = dict(value)
    status = supplied.pop("account_status", None)
    supplied_request_id = supplied.pop("status_request_id", None)
    if "account_status" in value and (not isinstance(status, str) or status not in ACCOUNT_STATUSES):
        raise AccountOperatingStatusError(
            "account_status_invalid", "账号状态必须是日更、周更或暂停"
        )
    if status is not None:
        if not actor.strip() or not reason.strip():
            raise AccountOperatingStatusError(
                "account_status_reason_required", "账号状态更新需要操作人和原因"
            )
        if "enabled" in supplied:
            if type(supplied["enabled"]) is not bool or supplied["enabled"] != (status != "paused"):
                raise AccountOperatingStatusError(
                    "account_status_conflict", "账号状态与采集开关冲突"
                )
            supplied.pop("enabled")
    elif "status_request_id" in value:
        raise AccountOperatingStatusError(
            "account_status_request_invalid", "账号状态请求编号需要同时提供账号状态"
        )
    request_id = (
        validate_status_request_id(supplied_request_id)
        if "status_request_id" in value else str(uuid4())
    )
    request = {"account_status": status, "fields": supplied}

    connection.execute("SAVEPOINT account_operating_status")
    try:
        existing = find_status_request(connection, request_id=request_id) if status is not None else None
        if existing is not None:
            payload = existing["payload"]
            if (
                payload["account_id"] != account_id
                or payload["request"] != request
                or payload["actor"] != actor
                or payload["reason"] != reason
            ):
                raise AccountOperatingStatusError(
                    "account_status_request_conflict", "该请求编号已用于不同的账号修改，请刷新后重试"
                )
            result = dict(payload["result"])
            result["status_replayed"] = True
            connection.execute("RELEASE account_operating_status")
            return result
        before = connection.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if before is None:
            raise AccountOperatingStatusError("account_not_found", "账号不存在")
        previous_frequency = load_update_frequencies(connection, [account_id])[account_id]
        frequency = status if status in {"daily", "weekly"} else previous_frequency
        result = update_account_in_transaction(
            connection, account_id, supplied, actor=actor, reason=reason,
            activation_id=activation_id,
        )
        roster_change: Mapping[str, Any] | None = None
        if status is not None:
            identity = connection.execute(
                "SELECT * FROM account_platform_identities WHERE account_id=?", (account_id,)
            ).fetchone()
            if identity is None:
                raise AccountOperatingStatusError(
                    "account_identity_not_found", "账号缺少平台身份，不能更新账号状态"
                )
            timestamp = datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
            set_account_enabled_in_transaction(
                connection, int(identity["id"]), enabled=status != "paused",
                effective_at=timestamp, created_at=timestamp, actor=actor, reason=reason,
                activation_id=activation_id,
                metadata={
                    "operation": "update_account_status", "account_status": status,
                    "previous_update_frequency": previous_frequency,
                },
            )
            # Changing daily <-> weekly on an enabled account only changes its
            # manual label. It must not silently repair/rebuild a roster.
            label_only = bool(before["enabled"]) and previous_frequency in {"daily", "weekly"} and status != "paused"
            if not label_only:
                members = current_system_members(connection)
                is_member = any(
                    member["platform"] == identity["platform"] and member["uid"] == identity["uid"]
                    for member in members
                )
                if status == "paused" and is_member:
                    roster_change = remove_system_member(
                        connection, account_id, raw_root=raw_root, actor=actor, reason=reason
                    )
                elif status != "paused" and not is_member:
                    roster_change = upsert_system_members(
                        connection, [_resume_member(connection, identity)],
                        raw_root=raw_root, actor=actor, reason=reason,
                    )
                    if roster_change.get("status") != "accepted":
                        raise AccountOperatingStatusError(
                            "account_resume_identity_invalid", "账号身份不完整，无法恢复到系统名单"
                        )
            if roster_change is not None and schedule_activation is not None:
                roster_change = schedule_activation(connection, roster_change)
        after = connection.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        assert after is not None
        result = {
            **result,
            "account_status": account_operating_status({**dict(after), "update_frequency": frequency}),
            "update_frequency": frequency,
            "enabled": bool(after["enabled"]),
        }
        if status == "paused":
            result["message"] = "账号已暂停，立即停用采集并退出新统计；历史数据保留。"
        elif status is not None:
            result["message"] = "账号状态已保存；日更、周更仅为人工运营标记。"
        if roster_change is not None:
            result["roster_change"] = dict(roster_change)
            result["message"] += " 系统名单变更在下一次北京时间零点激活后生效。"
        if status is not None:
            result["status_request_id"] = request_id
            record_status_receipt(
                connection, request_id=request_id, account_id=account_id,
                account_identity_id=int(identity["id"]), requested_status=status,
                update_frequency=frequency, request=request, actor=actor, reason=reason,
                before={"enabled": bool(before["enabled"]), "update_frequency": previous_frequency},
                after={"enabled": bool(after["enabled"]), "update_frequency": frequency},
                result=result, timestamp=timestamp,
            )
    except Exception:
        connection.execute("ROLLBACK TO account_operating_status")
        connection.execute("RELEASE account_operating_status")
        raise
    else:
        connection.execute("RELEASE account_operating_status")
        return result
