"""FastAPI application for DCar Insight v8 with temporary v7 read compatibility."""

from __future__ import annotations

import asyncio
import base64
import binascii
import csv
import fcntl
import hashlib
import io
import json
import logging
import os
import re
import sqlite3
import tempfile
import threading
from collections import OrderedDict
from copy import deepcopy
from concurrent.futures import Future, ThreadPoolExecutor
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone
from functools import lru_cache
from pathlib import Path
from time import monotonic
from typing import Any, Callable, Dict, List, Literal, Mapping, Optional
from urllib.parse import quote, unquote
from zoneinfo import ZoneInfo

from apscheduler.schedulers.background import BackgroundScheduler  # type: ignore[import-untyped]
from apscheduler.schedulers.base import STATE_PAUSED, STATE_RUNNING  # type: ignore[import-untyped]
from fastapi import APIRouter, BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel, ConfigDict, Field
from starlette.datastructures import Headers
from starlette.middleware.gzip import GZipResponder
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from . import media_api, media_consumer_proofs, media_retention
from .media_lifecycle import LifecycleError
from .account_roster import (
    RosterError,
    accept_candidate,
    account_summary,
    candidate_diff,
    current_snapshot,
    prepare_candidate,
    runtime_account_summary,
)
from .account_roster_upload import MAX_SOURCE_BYTES, decode_official_export
from .account_operating_status import (
    AccountOperatingStatusError,
    update_account_operating_status_in_transaction,
)
from .account_operating_receipts import ACCOUNT_STATUS_JOB, load_update_frequencies
from .statistics_scope import content_statistics_scope_sql
from .profile_activations import TIKHUB_PROFILE
from .profile_control import (
    ProfileControlError,
    enqueue_current_activation_hold_command,
    process_current_activation_hold_commands,
    read_current_activation_hold_command,
    schedule_accepted_roster_activation_in_transaction,
)
from .system_roster import (
    bootstrap_system_roster_from_matrix,
    current_system_members,
    remove_system_member,
    upsert_system_members,
)
from .capture import (
    BudgetBlocked,
    CaptureError,
    SlotUnavailable,
    recover_stale_fetch_slots,
)
from .contracts import (
    CURRENT_REPORT_VERSION,
    load_contract,
    quantity_metric,
    ratio_metric,
)
from .duplicates import FINGERPRINT_VERSION, THRESHOLDS, duplicate_metric_decision
from .evaluation_selectors import (
    DISPLAY_EFFECTIVE_EVALUATIONS_CTE,
    EvaluationSelectorError,
    FORMAL_CURRENT_EVALUATIONS_CTE,
    active_release,
    display_effective_evaluation,
    display_effective_evaluations_cte_for,
    effective_direction,
    effective_direction_sql,
    formal_eligible_release_evaluations,
)
from .audience_rate import active_classifier_state, build_channel_audience_rates
from .spu_audience import (
    STAT_PLATFORMS,
    STAT_WINDOWS,
    SpuAudienceError,
    associate_single_content,
    build_stats as build_spu_audience_stats,
    content_labels as spu_content_labels,
    default_llm_hook as default_spu_llm_hook,
    domain_ready as spu_domain_ready,
    list_assets as list_spu_audience_assets,
    recover_orphan_association_runs,
    resolve_incremental_since,
    run_association as run_spu_association,
    start_association_run,
    upsert_spu,
)
from .insights import CHANNELS, SCENES, build_channel_conclusions
from .source_routing import select_content_metrics
from .media import (
    MediaProcessingError,
    processor_versions,
    recover_stale_media_processing_slots,
)
from .operations import (
    account_read_model,
    account_scope_sql,
    OperationError,
    content_identity,
    export_accounts_xlsx,
    export_contents_csv,
    import_contents,
    update_account,
    update_content,
    upsert_content,
)
from .providers import (
    ProviderConfigurationError,
    retry_content_media,
    update_content_data_manual as update_content_data,
)
from .report_export import (
    accounts_workbook_filename,
    build_report_detail_workbook,
    build_report_download_bundle,
    platform_content_id_from_url,
    report_bundle_filename,
    report_file_filename,
)
from .runtime_database import (
    DatabaseAccessMode,
    FileIdentity,
    ResolvedDatabaseAccess,
    RuntimeDatabaseError,
    WriterLockLease,
    acquire_writer_lock,
    is_installed_formal_database,
    resolve_installed_database_access,
    resolve_isolated_candidate,
    resolve_isolated_fixture,
    resolve_read_only_replica,
)
from .reports import (
    IMPLICIT_RUN_STATUSES,
    REPORTS_ROOT,
    ReportTaskError,
    TaskCancelled,
    assert_report_runtime_ready,
    create_task,
    get_task,
    list_tasks,
    request_task_cancel,
    render_summary_png,
    render_summary_svg,
    retry_task,
    resume_task,
    run_task,
)
from .scheduler import (
    PIPELINE_REPORT_EXECUTION_LOCK,
    install_jobs,
    recover_interrupted_scheduler_runs,
    startup_catchup,
)
from .storage import (
    DEFAULT_DB,
    INSTALLED_LEGACY_DB,
    PROJECT_ROOT,
    SCHEMA_VERSION,
    connect,
    initialize_database,
    is_formal_database_path,
    now_utc,
    require_schema_compatibility,
    schema_compatibility_state,
    transaction,
)
from .taxonomy import (
    TaxonomyError,
    TaxonomyValidationError,
    create_point,
    delete_point,
    ensure_draft,
    list_points,
    publish_draft,
    serialize_point_row,
    update_point,
)


LOGGER = logging.getLogger("dcar.api")
DEFAULT_LEGACY_DB = INSTALLED_LEGACY_DB
DEFAULT_OPERATOR_FREEZE_LOCK = PROJECT_ROOT / "runtime" / "operator-freeze.lock"
DEFAULT_WRITER_LOCK = PROJECT_ROOT / "runtime" / "writer-worker.lock"
SHANGHAI = ZoneInfo("Asia/Shanghai")
LEGACY_REPORT_VERSION = "channel-structured-conclusions-v7.0"
LEGACY_EXPORTS = {
    "report-json": "report.json",
    "report-markdown": "report.md",
    "douyin-csv": "douyin_content_details.csv",
    "xiaohongshu-csv": "xiaohongshu_content_details.csv",
    "summary-image": "core_summary.png",
}
DOUYIN_URL_RE = re.compile(r"https?://(?:www\.)?douyin\.com/", re.I)
XHS_URL_RE = re.compile(r"https?://(?:www\.)?xiaohongshu\.com/", re.I)
UID_RE = re.compile(r"^\d{6,24}$")
RUNTIME_IDENTITY_SCHEMA = "dcar-runtime-identity-v1"
DAILY_CAPTURE_RECONCILE_INTERVAL_SECONDS = 300
DATA_FRESHNESS_CACHE_TTL_SECONDS = 60.0
WRITER_HEARTBEAT_INTERVAL_SECONDS = 60
WRITER_HEARTBEAT_MAX_AGE_SECONDS = 180


class JSONGZipResponder(GZipResponder):
    """Compress JSON while preserving byte ranges and binary/media responses."""

    async def send_with_compression(self, message: Message) -> None:
        if message["type"] == "http.response.start":
            self.initial_message = message
            headers = Headers(raw=message["headers"])
            media_type = headers.get("content-type", "").split(";", 1)[0].lower()
            status = int(message["status"])
            self.content_encoding_set = "content-encoding" in headers
            self.content_type_is_excluded = (
                status in {204, 206, 304}
                or "content-range" in headers
                or not (media_type == "application/json" or media_type.endswith("+json"))
            )
            return
        await super().send_with_compression(message)


class JSONGZipMiddleware:
    def __init__(
        self, app: ASGIApp, minimum_size: int = 1_000, compresslevel: int = 5
    ) -> None:
        self.app = app
        self.minimum_size = minimum_size
        self.compresslevel = compresslevel

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or "gzip" not in Headers(scope=scope).get(
            "Accept-Encoding", ""
        ):
            await self.app(scope, receive, send)
            return
        responder = JSONGZipResponder(
            self.app, self.minimum_size, compresslevel=self.compresslevel
        )
        await responder(scope, receive, send)


def _enabled(name: str) -> bool:
    return os.environ.get(name, "0").strip() == "1"


def _optional_strict_iso_date(name: str) -> date | None:
    raw = os.environ.get(name)
    if raw is None:
        return None
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw) is None:
        raise RuntimeError(f"{name} must use strict YYYY-MM-DD format")
    try:
        return date.fromisoformat(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be a valid YYYY-MM-DD date") from exc


@dataclass(frozen=True, slots=True)
class ApiConfig:
    db_path: Path
    reports_root: Path
    legacy_db_path: Path
    operator_freeze_lock: Path
    writer_lock: Path = DEFAULT_WRITER_LOCK
    scheduler_enabled: bool = False
    scheduler_start_paused: bool = False
    startup_catchup_enabled: bool = False
    read_only: bool = False
    daily_capture_reconcile_from: date | None = None
    runtime_access_mode: DatabaseAccessMode | None = None
    project_root: Path = PROJECT_ROOT
    runtime_from_environment: bool = False

    @classmethod
    def from_env(cls) -> "ApiConfig":
        freeze_value = os.environ.get("DCAR_OPERATOR_FREEZE_LOCK") or os.environ.get(
            "DCAR_FREEZE_LOCK"
        )
        scheduler_enabled = _enabled("DCAR_SCHEDULER_ENABLED")
        reconcile_from = _optional_strict_iso_date(
            "DCAR_DAILY_CAPTURE_RECONCILE_FROM"
        )
        configured_database = os.environ.get("DCAR_V8_DB")
        database = Path(configured_database or str(DEFAULT_DB))
        read_only = _enabled("DCAR_READ_ONLY")
        isolated_candidate = _enabled("DCAR_V8_ISOLATED_CANDIDATE")
        if isolated_candidate and (read_only or scheduler_enabled):
            raise RuntimeError(
                "DCAR_V8_ISOLATED_CANDIDATE conflicts with writer/read-only mode"
            )
        if read_only:
            access_mode = DatabaseAccessMode.FORMAL_READ
        elif isolated_candidate:
            access_mode = DatabaseAccessMode.ISOLATED_CANDIDATE
        elif scheduler_enabled or (
            configured_database
            and os.environ.get("DCAR_PROJECT_ROOT")
            and os.environ.get("DCAR_WRITER_LOCK")
        ):
            access_mode = DatabaseAccessMode.WRITER
        else:
            access_mode = None
        config = cls(
            db_path=database,
            reports_root=Path(
                os.environ.get("DCAR_V8_REPORTS_ROOT", str(REPORTS_ROOT))
            ),
            legacy_db_path=Path(
                os.environ.get("DCAR_LEGACY_DB", str(DEFAULT_LEGACY_DB))
            ),
            operator_freeze_lock=Path(
                freeze_value or str(DEFAULT_OPERATOR_FREEZE_LOCK)
            ),
            writer_lock=Path(
                os.environ.get("DCAR_WRITER_LOCK", str(DEFAULT_WRITER_LOCK))
            ),
            scheduler_enabled=scheduler_enabled,
            scheduler_start_paused=_enabled("DCAR_SCHEDULER_START_PAUSED"),
            startup_catchup_enabled=_enabled("DCAR_STARTUP_CATCHUP_ENABLED"),
            read_only=read_only,
            daily_capture_reconcile_from=reconcile_from,
            runtime_access_mode=access_mode,
            project_root=Path(os.environ.get("DCAR_PROJECT_ROOT", str(PROJECT_ROOT))),
            runtime_from_environment=True,
        )
        config.validate_daily_capture_reconcile_contract()
        return config

    def validate_daily_capture_reconcile_contract(self) -> None:
        """Reject reconcile settings that cannot be honored by this runtime."""

        if self.scheduler_start_paused and (not self.scheduler_enabled or self.read_only):
            raise RuntimeError(
                "DCAR_SCHEDULER_START_PAUSED requires writable mode and DCAR_SCHEDULER_ENABLED=1"
            )
        if self.daily_capture_reconcile_from is not None:
            if not self.scheduler_enabled and not self.read_only:
                raise RuntimeError(
                    "DCAR_DAILY_CAPTURE_RECONCILE_FROM requires "
                    "DCAR_SCHEDULER_ENABLED=1"
                )
        if self.read_only and self.scheduler_enabled:
            raise RuntimeError("DCAR_SCHEDULER_ENABLED requires writable mode")
        if self.scheduler_enabled and self.daily_capture_reconcile_from is None:
            raise RuntimeError(
                "DCAR_DAILY_CAPTURE_RECONCILE_FROM is required when "
                "DCAR_SCHEDULER_ENABLED=1"
            )

    @property
    def effective_startup_catchup_enabled(self) -> bool:
        return self.scheduler_enabled and self.startup_catchup_enabled and not self.scheduler_start_paused

    @property
    def effective_daily_capture_reconcile_from(self) -> date | None:
        self.validate_daily_capture_reconcile_contract()
        return self.daily_capture_reconcile_from


def _request_config(request: Request) -> ApiConfig:
    config = getattr(request.app.state, "config", None)
    if not isinstance(config, ApiConfig):
        raise RuntimeError("FastAPI application is missing ApiConfig")
    return config


def _connect_for_request(request: Request) -> sqlite3.Connection:
    config = _request_config(request)
    return connect(config.db_path, read_only=config.read_only)


class InputValidationRequest(BaseModel):
    channel: str = Field(max_length=32)
    text: str = Field(max_length=2_000_000)


class AccountSearchRequest(BaseModel):
    query: str = Field(default="", max_length=100)
    account_type: Optional[str] = Field(default=None, max_length=32)
    content_direction: Optional[str] = Field(default=None, max_length=32)
    platform: Optional[str] = Field(default=None, max_length=32)
    scope: Literal["current", "history", "unresolved", "all"] = "current"
    account_status: Optional[Literal["daily", "weekly", "paused", "unmarked"]] = None
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=50, ge=1, le=100)


class DouyinAuthorizationTarget(BaseModel):
    model_config = ConfigDict(extra="forbid")

    account_id: int = Field(ge=1)
    platform_uid: str = Field(min_length=6, max_length=24, pattern=r"^\d{6,24}$")
    state: Literal["authorized", "needs_reauthorization"]


class AccountExportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scope: Literal["current", "history", "unresolved", "all"] = "current"

    # None means the control-plane status request failed.  An empty list means
    # it succeeded and no exact account/UID pair currently has an active grant.
    douyin_authorization_targets: Optional[List[DouyinAuthorizationTarget]] = Field(
        default=None, max_length=100_000
    )


SELLING_POINT_NONE = "__none__"


class ContentSearchRequest(BaseModel):
    query: str = Field(default="", max_length=200)
    platform: Optional[str] = Field(default=None, max_length=32)
    account_type: Optional[str] = Field(default=None, max_length=32)
    content_direction: Optional[str] = Field(default=None, max_length=32)
    selling_point: Optional[str] = Field(default=None, max_length=8)
    spu_series: Optional[str] = Field(default=None, max_length=120)
    audience: Optional[str] = Field(default=None, max_length=16)
    scene: Optional[str] = Field(default=None, max_length=16)
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=50, ge=1, le=100)


class SellingPointMutationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: Optional[str] = Field(default=None, max_length=3)
    tier: str = Field(max_length=16)
    label: str = Field(min_length=1, max_length=300)
    definition: str = Field(default="", max_length=2000)
    matcher_rule: Dict[str, Any]


class SpuAliasPayload(BaseModel):
    alias: str = Field(min_length=1, max_length=60)
    alias_type: str = Field(default="official", max_length=16)
    ambiguous: bool = False


class SpuUpsertRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    spu_id: Optional[str] = Field(default=None, max_length=160)
    brand: str = Field(min_length=1, max_length=60)
    series: str = Field(min_length=1, max_length=80)
    trim_label: Optional[str] = Field(default=None, max_length=120)
    model_year: Optional[int] = Field(default=None, ge=1990, le=2100)
    powertrain: str = Field(default="", max_length=16)
    body_style: str = Field(default="", max_length=16)
    price_low: Optional[float] = Field(default=None, ge=0)
    price_high: Optional[float] = Field(default=None, ge=0)
    enabled: bool = True
    audience_primary: Optional[str] = Field(default=None, max_length=8)
    audience_secondary: Optional[str] = Field(default=None, max_length=8)
    basis: str = Field(default="页面配置", max_length=300)
    aliases: List[SpuAliasPayload] = Field(default_factory=list)


class TaskCreateRequest(BaseModel):
    period_start: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    period_end: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    name: Optional[str] = Field(default=None, max_length=200)


class AccountIdentityRequest(BaseModel):
    platform: str = Field(max_length=32)
    uid: str = Field(min_length=1, max_length=128)
    nickname: str = Field(default="", max_length=200)
    real_name_status: str = Field(default="unknown", max_length=16)


class AccountMutationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    phone: Optional[str] = Field(default="", max_length=50)
    operator_name: str = Field(default="", max_length=100)
    account_type: str = Field(default="unknown", max_length=32)
    content_direction: str = Field(default="unknown", max_length=32)
    enabled: bool = True
    account_status: Optional[Literal["daily", "weekly", "paused"]] = None
    status_request_id: Optional[str] = Field(default=None, min_length=1, max_length=128)


class SystemAccountMemberRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    platform: Literal["douyin", "xiaohongshu", "wechat_channels", "kuaishou"]
    uid: str = Field(min_length=1, max_length=128)
    nickname: str = Field(default="", max_length=200)
    profile_ref: Optional[str] = Field(default=None, max_length=3000)
    sec_user_id: Optional[str] = Field(default=None, max_length=300)


class SystemRosterBootstrapRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reason: str = Field(min_length=1, max_length=1000, pattern=r"\S")


class RosterUploadRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_name: str = Field(min_length=1, max_length=300)
    content_base64: str = Field(min_length=1, max_length=4 * ((MAX_SOURCE_BYTES + 2) // 3))
    organization: str = Field(min_length=1, max_length=300)
    source_exported_at: str = Field(min_length=1, max_length=60)
    source_instance_id: str = Field(min_length=1, max_length=300)
    declared_count: int = Field(ge=0, le=100_000)
    evidence_note: str = Field(min_length=1, max_length=4000)


class ContentMutationRequest(BaseModel):
    platform: str = Field(max_length=32)
    platform_content_id: Optional[str] = Field(default=None, max_length=128)
    canonical_url: str = Field(min_length=1, max_length=3000)
    published_at: Optional[str] = Field(default=None, max_length=50)
    title: str = Field(default="", max_length=1000)
    body: str = Field(default="", max_length=20000)
    content_type: str = Field(default="unknown", max_length=32)
    account_uid: str = Field(default="", max_length=128)
    account_name: str = Field(default="", max_length=200)
    account_type: str = Field(default="unknown", max_length=32)
    content_direction: str = Field(default="unknown", max_length=32)


class ContentPatchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    platform: Optional[str] = Field(default=None, max_length=32)
    platform_content_id: Optional[str] = Field(default=None, max_length=128)
    canonical_url: Optional[str] = Field(default=None, max_length=3000)
    published_at: Optional[str] = Field(default=None, max_length=50)
    title: Optional[str] = Field(default=None, max_length=1000)
    body: Optional[str] = Field(default=None, max_length=20000)
    content_type: Optional[str] = Field(default=None, max_length=32)
    account_uid: Optional[str] = Field(default=None, max_length=128)
    account_name: Optional[str] = Field(default=None, max_length=200)
    account_type: Optional[str] = Field(default=None, max_length=32)
    content_direction: Optional[str] = Field(default=None, max_length=32)


class BulkImportRequest(BaseModel):
    source_name: str = Field(min_length=1, max_length=300)
    rows: List[Dict[str, Any]] = Field(max_length=10000)


class MediaRetryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    allow_paid_refresh: bool = False


class MediaRestoreRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    bundle_id: str = Field(pattern=r"^[0-9a-f]{32}$")
    purpose: Literal["evidence", "reprocess"]


class TaskCorrectionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reason: str = Field(min_length=1, max_length=2000, pattern=r"\S")


class MediaProcessingSearchRequest(BaseModel):
    status: Optional[str] = Field(default=None, max_length=32)
    processor_type: Optional[str] = Field(default=None, max_length=40)
    content_id: Optional[int] = Field(default=None, ge=1)
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=50, ge=1, le=100)


class CurrentActivationHoldCommandRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    command_id: str = Field(
        min_length=1, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9_.:-]*$"
    )
    command: Literal[
        "hold_begin",
        "hold_build_advance",
        "hold_seal",
        "hold_release",
        "forward_only_release",
        "hold_reopen",
        "transport_primary",
        "transport_control",
    ]
    parameters: Optional[Dict[str, Any]] = None
    binding: Optional[Dict[str, Any]] = None


def _legacy_connect(legacy_db_path: Path) -> sqlite3.Connection:
    if _enabled("DCAR_READ_ONLY"):
        if not legacy_db_path.is_file():
            raise RuntimeError(
                f"read-only legacy SQLite database is missing: {legacy_db_path}"
            )
        connection = sqlite3.connect(
            f"{legacy_db_path.resolve().as_uri()}?mode=ro&immutable=1",
            uri=True,
            timeout=10,
        )
        connection.execute("PRAGMA query_only = ON")
    else:
        connection = sqlite3.connect(legacy_db_path, timeout=10)
    connection.row_factory = sqlite3.Row
    return connection


def _safe_project_path(value: str) -> Path:
    from .artifact_paths import resolve
    path = resolve(value, fallback_root=PROJECT_ROOT).resolve()
    root = PROJECT_ROOT.resolve()
    if path != root and root not in path.parents:
        raise HTTPException(status_code=400, detail="文件暂时无法读取，请联系管理员。")
    return path


def _legacy_formal_report_path(legacy_db_path: Path) -> Path:
    with _legacy_connect(legacy_db_path) as connection:
        row = connection.execute(
            """
            SELECT r.output_path
            FROM formal_baseline b JOIN runs r ON r.id=b.run_id
            WHERE b.singleton_id=1 AND r.status='completed' AND r.report_stale=0
            """
        ).fetchone()
        if row is None:
            row = connection.execute(
                """
                SELECT output_path FROM runs
                WHERE status='completed' AND report_version=? AND report_stale=0
                  AND output_path IS NOT NULL
                ORDER BY updated_at DESC LIMIT 1
                """,
                (LEGACY_REPORT_VERSION,),
            ).fetchone()
    if row is None or not row["output_path"]:
        raise HTTPException(status_code=404, detail="还没有可查看的历史报告。")
    path = _safe_project_path(str(row["output_path"]))
    if not path.exists():
        raise HTTPException(
            status_code=404, detail="历史报告文件丢失，请重新生成报告。"
        )
    return path


def _legacy_report(legacy_db_path: Path) -> Dict[str, Any]:
    return json.loads(
        _legacy_formal_report_path(legacy_db_path).read_text(encoding="utf-8")
    )


def _legacy_runs(legacy_db_path: Path, limit: int = 20) -> List[Dict[str, Any]]:
    with _legacy_connect(legacy_db_path) as connection:
        rows = connection.execute(
            "SELECT * FROM runs ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(row) for row in rows]


def _legacy_run(legacy_db_path: Path, run_id: str) -> Optional[Dict[str, Any]]:
    with _legacy_connect(legacy_db_path) as connection:
        row = connection.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
    return dict(row) if row else None


def _legacy_overview(legacy_db_path: Path) -> Dict[str, Any]:
    report = _legacy_report(legacy_db_path)
    channels = report["channels"]
    return {
        "status": "ready",
        "report_version": report["report_version"],
        "rule_version": report["rule_version"],
        "generated_at": report["metadata"]["generated_at"],
        "run_id": report["metadata"]["run_id"],
        "revision": report["metadata"]["revision"],
        "run_summary": report["run_summary"],
        "channels": {
            name: {
                "denominator": channels[name]["denominator"],
                "count_distribution": channels[name]["count_distribution"],
                "verticality": channels[name]["verticality"],
            }
            for name in ("douyin", "xiaohongshu")
        },
        "workflow": {
            "mode": "legacy_v7_read_only",
            "provider_refresh_enabled": False,
            "actual_acquisition_connected": False,
            "formal_baseline": True,
        },
        "recent_runs": _legacy_runs(legacy_db_path, 8),
    }


def _validate_legacy_inputs(channel: str, text: str) -> Dict[str, Any]:
    items = [
        line.strip() for line in text.replace(",", "\n").splitlines() if line.strip()
    ]
    unique = list(dict.fromkeys(items))
    valid: List[str] = []
    invalid: List[Dict[str, str]] = []
    for item in unique:
        if channel == "douyin":
            accepted = bool(DOUYIN_URL_RE.search(item) or UID_RE.fullmatch(item))
            reason = "不是抖音链接或6-24位数字UID"
        elif channel == "xiaohongshu":
            accepted = bool(XHS_URL_RE.search(item))
            reason = "不是小红书内容链接"
        else:
            accepted = False
            reason = "渠道只支持douyin或xiaohongshu"
        if accepted:
            valid.append(item)
        else:
            invalid.append({"value": item[:200], "reason": reason})
    return {
        "channel": channel,
        "total": len(items),
        "unique": len(unique),
        "valid_count": len(valid),
        "invalid_count": len(invalid),
        "valid": valid,
        "invalid": invalid,
        "can_start": bool(valid) and not invalid,
        "mode": "validation_only",
    }


def _utc_text(value: datetime) -> str:
    return (
        value.astimezone(timezone.utc)
        .isoformat(timespec="seconds")
        .replace("+00:00", "Z")
    )


def _windows(now: Optional[datetime] = None) -> Dict[str, tuple[datetime, datetime]]:
    current = (now or datetime.now(SHANGHAI)).astimezone(SHANGHAI)
    today = datetime.combine(current.date(), time.min, tzinfo=SHANGHAI)
    this_week = today - timedelta(days=today.weekday())
    return {
        "yesterday": (today - timedelta(days=1), today),
        "this_week": (this_week, current),
        "last_week": (this_week - timedelta(days=7), this_week),
    }


def _overview_stage(
    timings: Optional[Dict[str, Any]], name: str, started_at: float
) -> None:
    if timings is not None:
        timings[name] = timings.get(name, 0.0) + (monotonic() - started_at) * 1000


def _window_content_rows(
    connection: sqlite3.Connection,
    start: datetime,
    end: datetime,
) -> List[sqlite3.Row]:
    return connection.execute(
        f"""
        SELECT c.id, c.account_id, c.platform, c.manual_content_direction,
               c.evaluation_content_direction, a.content_direction account_content_direction
        FROM content_items c
        LEFT JOIN accounts a ON a.id=c.account_id
        WHERE c.published_at >= ? AND c.published_at < ?
          AND {content_statistics_scope_sql("c")}
        """,
        (_utc_text(start), _utc_text(end)),
    ).fetchall()


@dataclass
class _OverviewFacts:
    evaluations: Dict[int, Dict[str, Any]]
    metrics: Dict[int, Dict[str, Any]]


def _overview_facts(
    connection: sqlite3.Connection,
    content_ids: List[int],
    *,
    timings: Optional[Dict[str, Any]] = None,
) -> _OverviewFacts:
    """Select current facts once for the union of the overview windows."""
    if not content_ids:
        return _OverviewFacts({}, {})
    started_at = monotonic()
    release = active_release(connection)
    assert release is not None
    eligible = formal_eligible_release_evaluations(
        connection, str(release["id"]), content_ids
    )
    tier_by_code = {
        str(row["code"]): row["tier"]
        for row in connection.execute(
            """
            SELECT sp.code,sp.tier FROM selling_points sp
            JOIN taxonomy_versions tv ON tv.id=sp.taxonomy_id
            WHERE tv.version=?
            """,
            (release["taxonomy_version"],),
        )
    }
    evaluations = {
        content_id: {
            **value,
            "primary_tier": tier_by_code.get(str(value["primary_selling_point_code"]))
            if value.get("primary_selling_point_code") else None,
        }
        for content_id, value in eligible.items()
    }
    _overview_stage(timings, "evaluations", started_at)
    started_at = monotonic()
    # Keep the current-read selector mode: passing cutoff_at would disable
    # the explicitly stale legacy-snapshot fallback.
    metrics = select_content_metrics(
        connection, content_ids, metric_fields=("view_count", "comment_count")
    )
    _overview_stage(timings, "metrics", started_at)
    return _OverviewFacts(evaluations, metrics)


def _window_summary(
    connection: sqlite3.Connection,
    start: datetime,
    end: datetime,
    *,
    report_cutoff_at: Optional[str] = None,
    content_rows: Optional[List[sqlite3.Row]] = None,
    facts: Optional[_OverviewFacts] = None,
    timings: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    contract = load_contract(report_version=CURRENT_REPORT_VERSION)
    coverage_thresholds = contract["required_coverage_thresholds"]
    metric_display_thresholds = contract["metric_display_coverage_thresholds"]
    evaluation_minimum = float(coverage_thresholds["evaluation_coverage"])
    fingerprint_minimum = float(
        coverage_thresholds["duplicate_fingerprint_coverage"]
    )
    view_minimum = float(metric_display_thresholds["view_count"])
    comment_minimum = float(metric_display_thresholds["comment_count"])
    if content_rows is None:
        content_rows = _window_content_rows(connection, start, end)
    content_ids = [int(row["id"]) for row in content_rows]
    total = len(content_ids)
    active_accounts = len(
        {
            int(row["account_id"])
            for row in content_rows
            if row["account_id"] is not None
        }
    )
    if content_ids:
        placeholders = ",".join("?" for _ in content_ids)
        if facts is None:
            facts = _overview_facts(connection, content_ids, timings=timings)
        evaluations = [
            facts.evaluations[content_id]
            for content_id in content_ids if content_id in facts.evaluations
        ]
        metrics = [
            facts.metrics[content_id]
            for content_id in content_ids if content_id in facts.metrics
        ]
        duplicate_count = int(
            connection.execute(
                f"""
                SELECT COUNT(DISTINCT duplicate_content_id) FROM duplicate_relations
                WHERE status='confirmed' AND duplicate_content_id IN ({placeholders})
                """,
                content_ids,
            ).fetchone()[0]
        )
        fingerprint_count = int(
            connection.execute(
                f"""
                SELECT COUNT(DISTINCT content_id) FROM duplicate_fingerprints
                WHERE fingerprint_version=? AND content_id IN ({placeholders})
                """,
                [FINGERPRINT_VERSION, *content_ids],
            ).fetchone()[0]
        )
        duplicate_calibrated = (
            connection.execute(
                """
            SELECT 1 FROM duplicate_calibration_runs
            WHERE fingerprint_version=? AND thresholds_json=? AND status='passed' LIMIT 1
            """,
                (
                    FINGERPRINT_VERSION,
                    json.dumps(
                        THRESHOLDS,
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                ),
            ).fetchone()
            is not None
        )
    else:
        evaluations, metrics = [], []
        duplicate_count = fingerprint_count = 0
        duplicate_calibrated = False
    evaluation_values = [dict(row) for row in evaluations]
    metric_values = [dict(row) for row in metrics]
    evaluation_by_content = {int(row["content_id"]): row for row in evaluation_values}
    metric_by_content = {int(row["content_id"]): row for row in metric_values}
    conclusion_rows: List[Dict[str, Any]] = []
    for content_row in content_rows:
        content = dict(content_row)
        content_id = int(content["id"])
        evaluation = evaluation_by_content.get(content_id, {})
        metric = metric_by_content.get(content_id, {})
        formal_content = {**content, "evaluation_content_direction": None}
        conclusion_rows.append(
            {
                "content_id": content_id,
                "platform": str(content["platform"]),
                "content_direction": effective_direction(formal_content, evaluation),
                "evidence_level": evaluation.get("evidence_level"),
                "selling_point_included": bool(
                    evaluation.get("selling_point_included")
                ),
                "primary_tier": evaluation.get("primary_tier"),
                "content_automotive_score": evaluation.get("content_automotive_score"),
                "audience_automotive_score": evaluation.get(
                    "audience_automotive_score"
                ),
                "acquisition_potential_score": evaluation.get(
                    "acquisition_potential_score"
                ),
                "view_count": metric.get("view_count"),
            }
        )
    eligible = sum(
        1 for row in evaluation_values if row["evidence_level"] in {"V2", "V3"}
    )
    vertical = sum(
        1
        for row in evaluation_values
        if row["evidence_level"] in {"V2", "V3"}
        and row["content_automotive_score"] is not None
        and int(row["content_automotive_score"]) >= 60
    )
    selling = sum(
        1 for row in evaluation_values if int(row["selling_point_included"]) == 1
    )
    view_values = [
        int(row["view_count"]) for row in metric_values if row["view_count"] is not None
    ]
    comment_values = [
        int(row["comment_count"])
        for row in metric_values
        if row["comment_count"] is not None
    ]
    view_eligible = sum(str(row["platform"]) == "douyin" for row in content_rows)
    view_coverage = round(len(view_values) * 100 / view_eligible, 2) if view_eligible else None
    comment_coverage = round(len(comment_values) * 100 / total, 2) if total else None
    views = sum(view_values)
    comments = sum(comment_values)
    evaluation_coverage = round(eligible * 100 / total, 2) if total else None
    ratio_status = (
        "not_applicable"
        if total == 0
        else "available"
        if (evaluation_coverage or 0) >= evaluation_minimum
        else "below_threshold"
    )
    evaluation_reason = (
        f"卖点评估完成率为 {evaluation_coverage:.2f}%，低于至少 "
        f"{evaluation_minimum:g}% 的要求"
        if ratio_status == "below_threshold" and evaluation_coverage is not None
        else ""
    )
    duplicate_status, duplicate_coverage, duplicate_reason = duplicate_metric_decision(
        total,
        fingerprint_count,
        duplicate_calibrated,
        threshold=fingerprint_minimum,
    )
    started_at = monotonic()
    audience_rates = _audience_rates(
        connection, conclusion_rows, end, report_cutoff_at=report_cutoff_at
    )
    _overview_stage(timings, "audience", started_at)
    return {
        "period_start": start.isoformat(),
        "period_end": end.isoformat(),
        "eligible_count": eligible,
        "unassociated_content_count": sum(
            1 for row in content_rows if row["account_id"] is None
        ),
        "metrics": {
            "publication_count": quantity_metric(
                total, unit="content", status="available"
            ),
            "active_account_count": quantity_metric(
                active_accounts, unit="account", status="available"
            ),
            "view_count": quantity_metric(
                views if view_values else None,
                unit="view",
                status="not_applicable"
                if view_eligible == 0
                else "missing"
                if not view_values
                else "available"
                if (view_coverage or 0) >= view_minimum
                else "below_threshold",
                coverage_percentage=view_coverage,
                reason=(
                    f"有曝光量的数据占 {view_coverage:.2f}%，低于至少 "
                    f"{view_minimum:g}% 的要求"
                    if view_values and (view_coverage or 0) < view_minimum
                    else ""
                ),
            ),
            "comment_count": quantity_metric(
                comments if comment_values else None,
                unit="comment",
                status="not_applicable"
                if total == 0
                else "missing"
                if not comment_values
                else "available"
                if (comment_coverage or 0) >= comment_minimum
                else "below_threshold",
                coverage_percentage=comment_coverage,
                reason=(
                    f"有评论数的数据占 {comment_coverage:.2f}%，低于至少 "
                    f"{comment_minimum:g}% 的要求"
                    if comment_values and (comment_coverage or 0) < comment_minimum
                    else ""
                ),
            ),
            "verticality_rate": ratio_metric(
                vertical if total else None,
                total,
                status=ratio_status,
                eligible_count=eligible,
                coverage_percentage=evaluation_coverage,
                reason=evaluation_reason,
            ),
            "selling_point_coverage_rate": ratio_metric(
                selling if total else None,
                total,
                status=ratio_status,
                eligible_count=eligible,
                coverage_percentage=evaluation_coverage,
                reason=evaluation_reason,
            ),
            "duplicate_rate": ratio_metric(
                duplicate_count if total else None,
                total,
                status=duplicate_status,
                eligible_count=fingerprint_count,
                coverage_percentage=duplicate_coverage,
                reason=duplicate_reason,
            ),
            "estimated_new_users": quantity_metric(
                None,
                unit="person",
                status="not_applicable" if total == 0 else "not_calculable",
                reason="系统暂时无法计算这项数据。",
            ),
            "estimated_reactivated_users": quantity_metric(
                None,
                unit="person",
                status="not_applicable" if total == 0 else "not_calculable",
                reason="系统暂时无法计算这项数据。",
            ),
            "estimated_leads": quantity_metric(
                None,
                unit="lead",
                status="not_applicable" if total == 0 else "not_calculable",
                reason="系统暂时无法计算这项数据。",
            ),
        },
        "channels": build_channel_conclusions(
            conclusion_rows,
            audience_rates=audience_rates,
        ),
    }


def _audience_rates(
    connection: sqlite3.Connection,
    conclusion_rows: List[Dict[str, Any]],
    window_end: datetime,
    *,
    report_cutoff_at: Optional[str] = None,
) -> Dict[str, Dict[str, Any]]:
    """Compute per-slice automotive_user_rate for the overview window.

    An uncalibrated classifier may publish only a complete classified sample;
    missing identities or classifications always keep the percentage hidden.
    """

    evidence_window_end = _utc_text(window_end)
    evidence_window_start = _utc_text(window_end - timedelta(days=90))
    return build_channel_audience_rates(
        connection,
        conclusion_rows,
        classifier_state=_active_classifier_state(connection),
        evidence_window_start=evidence_window_start,
        evidence_window_end=evidence_window_end,
        report_cutoff_at=report_cutoff_at or now_utc(),
        warm_up=True,
        channels=CHANNELS,
        scenes=SCENES,
    )


def _active_classifier_state(connection: sqlite3.Connection) -> str:
    """Resolve the calibrated classifier state through the shared gate."""

    return active_classifier_state(connection)


def _parse_timestamp(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _data_freshness(
    connection: sqlite3.Connection,
    *,
    current_at: Optional[datetime] = None,
) -> Dict[str, Any]:
    """Read the latest DB coverage receipt without traversing raw manifests."""
    from .runtime_receipts import latest_runtime_coverage

    if not connection.in_transaction:
        connection.execute("BEGIN")
    reference = current_at or datetime.now(timezone.utc)
    if reference.tzinfo is None:
        reference = reference.replace(tzinfo=timezone.utc)
    timestamp = reference.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    coverage = latest_runtime_coverage(connection, at=timestamp)
    latest = None
    if coverage.get("round_run_id") is not None:
        row = connection.execute("SELECT * FROM scheduler_runs WHERE id=?", (coverage["round_run_id"],)).fetchone()
        if row is not None:
            identity = json.loads(row["details_json"]).get("identity", {})
            latest = {"id": row["id"], "job_id": row["job_id"],
                      "scheduled_for": identity.get("scheduled_at") or row["started_at"],
                      "status": row["status"], "completed_at": row["completed_at"]}
    stage_queries = {
        "matrix_work_metrics": "SELECT MAX(captured_at) FROM content_metric_observations WHERE source='newrank_matrix' AND observation_origin='provider_capture' AND julianday(captured_at)<=julianday(?) AND julianday(recorded_at)<=julianday(?)",
        "matrix_account_metrics": "SELECT MAX(captured_at) FROM account_metric_observations WHERE source='newrank_matrix' AND julianday(captured_at)<=julianday(?) AND julianday(recorded_at)<=julianday(?)",
        "tikhub_detail": """SELECT MAX(p.captured_at) FROM provider_raw_responses p
            JOIN fetch_attempts a ON a.id=p.fetch_attempt_id JOIN fetch_slots s ON s.id=a.slot_id
            WHERE lower(p.provider)='tikhub' AND p.source IN ('live_applied','derived_applied')
              AND s.stage='detail' AND s.status='succeeded' AND a.error_code IS NULL
              AND julianday(p.captured_at)<=julianday(?) AND julianday(s.finished_at)<=julianday(?)""",
        "tikhub_metric_supplement": "SELECT MAX(captured_at) FROM content_metric_observations WHERE source='tikhub' AND observation_origin='provider_capture' AND julianday(captured_at)<=julianday(?) AND julianday(recorded_at)<=julianday(?)",
        "tikhub_comments": """SELECT MAX(c.captured_at) FROM comment_evidence_versions c
            JOIN comment_capture_runs r ON r.id=c.capture_run_id
            WHERE lower(r.provider)='tikhub' AND r.status='succeeded' AND c.status='available'
              AND julianday(c.captured_at)<=julianday(?) AND julianday(c.created_at)<=julianday(?)""",
        "local_media": "SELECT MAX(updated_at) FROM media_processing_slots WHERE status='succeeded' AND julianday(updated_at)<=julianday(?) AND julianday(created_at)<=julianday(?)",
        "local_evaluation": "SELECT MAX(evaluated_at) FROM evaluation_versions WHERE evaluation_source='automatic' AND evaluation_status='evaluated' AND invalidated_at IS NULL AND julianday(evaluated_at)<=julianday(?) AND julianday(evaluated_at)<=julianday(?)",
    }
    stage_data = {name: connection.execute(sql, (timestamp, timestamp)).fetchone()[0] for name, sql in stage_queries.items()}
    latest_published = connection.execute(
        f"SELECT MAX(c.published_at) FROM content_items c "
        f"WHERE c.platform IN ('douyin','xiaohongshu') AND {content_statistics_scope_sql('c')}"
    ).fetchone()[0]
    return {
        "status": (
            "current"
            if coverage["complete"]
            else "stale"
            if coverage["status"] in {"incomplete", "partial_publishable"}
            else "unknown"
        ),
        "basis": "profile-day-coverage-receipt-v2",
        "latest_published_at": latest_published,
        "last_successful_capture_at": latest["completed_at"] if latest and latest["status"] == "succeeded" and coverage["complete"] else None,
        "latest_capture_run": latest, "discovery_coverage": coverage,
        "stage_data": stage_data,
    }


@dataclass(slots=True)
class DataFreshnessCache:
    """Single-flight cache for the expensive verified runtime coverage scan."""

    ttl_seconds: float = DATA_FRESHNESS_CACHE_TTL_SECONDS
    clock: Callable[[], float] = field(default=monotonic, repr=False)
    _lock: Any = field(default_factory=threading.Lock, init=False, repr=False)
    _value: Optional[Dict[str, Any]] = field(default=None, init=False, repr=False)
    _expires_at: float = field(default=0.0, init=False, repr=False)
    _inflight: Optional[Future[Dict[str, Any]]] = field(
        default=None,
        init=False,
        repr=False,
    )

    def get(self, loader: Callable[[], Dict[str, Any]]) -> Dict[str, Any]:
        if self.ttl_seconds <= 0:
            return loader()
        with self._lock:
            if self._value is not None and self.clock() < self._expires_at:
                return deepcopy(self._value)
            future = self._inflight
            owner = future is None
            if owner:
                future = Future()
                self._inflight = future
        assert future is not None
        if not owner:
            return deepcopy(future.result())
        try:
            value = deepcopy(loader())
        except BaseException as exc:
            future.set_exception(exc)
            with self._lock:
                if self._inflight is future:
                    self._inflight = None
            raise
        with self._lock:
            self._value = value
            self._expires_at = self.clock() + self.ttl_seconds
            if self._inflight is future:
                self._inflight = None
        future.set_result(value)
        return deepcopy(value)


@dataclass(slots=True)
class ReadModelCache:
    """Short, bounded single-flight cache for expensive dashboard responses.

    The writer frequently commits operational progress to the WAL, so file
    timestamps are not a useful semantic invalidation signal for these read
    models: using them turns expensive reads into cache misses.  The TTL matches
    the UI's already bounded-stale reads while keeping repeat visits instant.
    """

    ttl_seconds: float = 30.0
    max_entries: int = 32
    clock: Callable[[], float] = field(default=monotonic, repr=False)
    _lock: Any = field(default_factory=threading.Lock, init=False, repr=False)
    _values: Any = field(default_factory=OrderedDict, init=False, repr=False)
    _generation: int = field(default=0, init=False, repr=False)
    _inflight: dict[tuple[Any, ...], Future[Dict[str, Any]]] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )

    def clear(self) -> None:
        """Invalidate values without letting an older in-flight load refill them."""
        with self._lock:
            self._generation += 1
            self._values.clear()

    def get(
        self,
        db_path: Path,
        key: tuple[Any, ...],
        loader: Callable[[], Dict[str, Any]],
        *,
        timings: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if self.ttl_seconds <= 0 or self.max_entries <= 0:
            if timings is not None:
                timings["cache"] = "bypass"
            return loader()
        with self._lock:
            generation = self._generation
            cache_key = (generation, str(db_path.resolve()), *key)
            cached = self._values.get(cache_key)
            if cached is not None:
                expires_at, value = cached
                if self.clock() < expires_at:
                    if timings is not None:
                        timings["cache"] = "hit"
                    self._values.move_to_end(cache_key)
                    return deepcopy(value)
                del self._values[cache_key]
            future = self._inflight.get(cache_key)
            owner = future is None
            if owner:
                future = Future()
                self._inflight[cache_key] = future
        assert future is not None
        if timings is not None:
            timings["cache"] = "miss" if owner else "wait"
        if not owner:
            return deepcopy(future.result())
        try:
            value = deepcopy(loader())
        except BaseException as exc:
            future.set_exception(exc)
            with self._lock:
                self._inflight.pop(cache_key, None)
            raise
        with self._lock:
            if generation == self._generation:
                self._values[cache_key] = (self.clock() + self.ttl_seconds, value)
                self._values.move_to_end(cache_key)
                while len(self._values) > self.max_entries:
                    self._values.popitem(last=False)
            self._inflight.pop(cache_key, None)
        future.set_result(value)
        return deepcopy(value)


def _request_read_model(
    request: Request,
    key: tuple[Any, ...],
    loader: Callable[[], Dict[str, Any]],
    *,
    timings: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    cache = getattr(request.app.state, "read_model_cache", None)
    config = _request_config(request)
    return (
        cache.get(config.db_path, key, loader, timings=timings)
        if isinstance(cache, ReadModelCache)
        else loader()
    )


def _request_data_freshness(
    request: Request,
    *,
    current_at: Optional[datetime] = None,
) -> Dict[str, Any]:
    config = _request_config(request)

    def load() -> Dict[str, Any]:
        with connect(config.db_path, read_only=config.read_only) as connection:
            return _data_freshness(connection, current_at=current_at)

    cache = getattr(request.app.state, "data_freshness_cache", None)
    return cache.get(load) if isinstance(cache, DataFreshnessCache) else load()


def _database_state(connection: sqlite3.Connection) -> Dict[str, Any]:
    """Return cheap snapshot identity fields used by deployment smoke checks."""

    compatibility = schema_compatibility_state(connection)
    user_version = int(connection.execute("PRAGMA user_version").fetchone()[0])
    release_rows = connection.execute(
        """
        SELECT er.id,er.rule_version,er.taxonomy_version,
               er.matcher_rule_sha256,er.status release_status,
               tv.status taxonomy_status
        FROM evaluation_releases er
        JOIN taxonomy_versions tv ON tv.version=er.taxonomy_version
        WHERE er.status='active'
        ORDER BY er.id
        """
    ).fetchall()
    if len(release_rows) != 1:
        raise RuntimeError(
            "database identity requires exactly one active evaluation release"
        )
    release = release_rows[0]
    runtime_identity = {
        "schema": RUNTIME_IDENTITY_SCHEMA,
        "report_version": CURRENT_REPORT_VERSION,
        "database_schema_version": user_version,
        "database_schema_migration": compatibility["actual_migration_name"],
        "active_release_id": str(release["id"]),
        "active_release_status": str(release["release_status"]),
        "rule_version": str(release["rule_version"]),
        "taxonomy_version": str(release["taxonomy_version"]),
        "taxonomy_status": str(release["taxonomy_status"]),
        "matcher_rule_sha256": str(release["matcher_rule_sha256"]),
    }
    return {
        "content_count": int(
            connection.execute("SELECT COUNT(*) FROM content_items").fetchone()[0]
        ),
        "latest_published_at": connection.execute(
            "SELECT MAX(published_at) FROM content_items"
        ).fetchone()[0],
        "user_version": user_version,
        "schema_compatibility": compatibility,
        "runtime_identity": runtime_identity,
    }


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


@lru_cache(maxsize=2048)
def _cached_file_sha256(path_value: str, byte_size: int, mtime_ns: int) -> str:
    del byte_size, mtime_ns
    return _file_sha256(Path(path_value))


def v8_overview(
    db_path: Path,
    *,
    read_only: bool = False,
    data_freshness: Optional[Mapping[str, Any]] = None,
    timings: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    overview_now = datetime.now(SHANGHAI)
    report_cutoff_at = now_utc()
    started_at = monotonic()
    with connect(db_path, read_only=read_only) as connection:
        _overview_stage(timings, "connect", started_at)
        # All three windows observe the same committed database snapshot.
        connection.execute("BEGIN")
        window_bounds = _windows(overview_now)
        started_at = monotonic()
        window_rows = {
            key: _window_content_rows(connection, start, end)
            for key, (start, end) in window_bounds.items()
        }
        content_ids = sorted({
            int(row["id"]) for rows in window_rows.values() for row in rows
        })
        _overview_stage(timings, "contents", started_at)
        facts = _overview_facts(connection, content_ids, timings=timings)
        started_at = monotonic()
        windows = {
            key: _window_summary(
                connection,
                start,
                end,
                report_cutoff_at=report_cutoff_at,
                content_rows=window_rows[key],
                facts=facts,
                timings=timings,
            )
            for key, (start, end) in window_bounds.items()
        }
        _overview_stage(timings, "windows", started_at)
        started_at = monotonic()
        quality = {
            "missing_published_at": int(
                connection.execute(
                    f"SELECT COUNT(*) FROM content_items c WHERE c.published_at IS NULL AND {content_statistics_scope_sql("c")}"
                ).fetchone()[0]
            ),
            "duplicate_fingerprint_coverage": round(
                int(
                    connection.execute(
                        f"SELECT COUNT(DISTINCT d.content_id) FROM duplicate_fingerprints d JOIN content_items c ON c.id=d.content_id WHERE d.fingerprint_version=? AND {content_statistics_scope_sql("c")}",
                        (FINGERPRINT_VERSION,),
                    ).fetchone()[0]
                )
                * 100
                / max(
                    1,
                    int(
                        connection.execute(
                            f"SELECT COUNT(*) FROM content_items c WHERE {content_statistics_scope_sql("c")}"
                        ).fetchone()[0]
                    ),
                ),
                2,
            ),
            "duplicate_calibration_ready": connection.execute(
                """
                SELECT 1 FROM duplicate_calibration_runs
                WHERE fingerprint_version=? AND thresholds_json=? AND status='passed' LIMIT 1
                """,
                (
                    FINGERPRINT_VERSION,
                    json.dumps(
                        THRESHOLDS,
                        ensure_ascii=False,
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                ),
            ).fetchone()
            is not None,
            "confirmed_duplicate_count": int(
                connection.execute(
                    f"SELECT COUNT(DISTINCT d.duplicate_content_id) FROM duplicate_relations d JOIN content_items c ON c.id=d.duplicate_content_id WHERE d.status='confirmed' AND {content_statistics_scope_sql("c")}"
                ).fetchone()[0]
            ),
        }
        freshness = (
            deepcopy(dict(data_freshness))
            if data_freshness is not None
            else _data_freshness(connection, current_at=overview_now)
        )
        _overview_stage(timings, "quality", started_at)
    return {
        "status": "ready",
        "report_version": CURRENT_REPORT_VERSION,
        "generated_at": report_cutoff_at,
        "timezone": "Asia/Shanghai",
        "windows": windows,
        "data_quality": quality,
        "data_freshness": freshness,
    }


def _account_search(
    payload: AccountSearchRequest, *, db_path: Path, read_only: bool = False
) -> Dict[str, Any]:
    where: List[str] = []
    parameters: List[Any] = []
    if payload.query:
        where.append(
            "(a.phone LIKE ? OR a.phone_normalized LIKE ? OR a.operator_name LIKE ? OR "
            "EXISTS (SELECT 1 FROM account_platform_identities i "
            "LEFT JOIN account_roster_members m ON m.account_identity_id=i.id "
            "WHERE i.account_id=a.id AND (i.uid LIKE ? OR i.nickname LIKE ? OR "
            "m.matrix_account_id LIKE ? OR json_extract(m.metadata_json,'$.display_account_id') LIKE ? OR "
            "json_extract(m.metadata_json,'$.nickname') LIKE ?)))"
        )
        pattern = f"%{payload.query}%"
        phone_digits = re.sub(r"\D", "", payload.query)
        normalized_pattern = f"%{phone_digits}%" if phone_digits else pattern
        parameters.extend([pattern, normalized_pattern, pattern, pattern, pattern, pattern, pattern, pattern])
    if payload.account_type:
        where.append("a.account_type=?")
        parameters.append(payload.account_type)
    if payload.content_direction:
        where.append("a.content_direction=?")
        parameters.append(payload.content_direction)
    if payload.platform:
        where.append(
            "EXISTS (SELECT 1 FROM account_platform_identities i "
            "WHERE i.account_id=a.id AND i.platform=?)"
        )
        parameters.append(payload.platform)
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""
    offset = (payload.page - 1) * payload.page_size
    with connect(db_path, read_only=read_only) as connection:
        active_release(connection)
        roster = runtime_account_summary(connection)
        try:
            frequencies = load_update_frequencies(connection)
        except AccountOperatingStatusError as exc:
            raise HTTPException(status_code=503, detail="账号状态记录校验失败，暂时无法读取。") from exc
        if payload.account_status:
            if payload.account_status == "paused":
                status_predicate = "a.enabled=0"
            elif payload.account_status == "unmarked":
                status_predicate = "a.enabled=1 AND a.id NOT IN (SELECT value FROM json_each(?))"
                parameters.append(json.dumps([key for key, value in frequencies.items() if value is not None]))
            else:
                status_predicate = "a.enabled=1 AND a.id IN (SELECT value FROM json_each(?))"
                parameters.append(json.dumps([key for key, value in frequencies.items() if value == payload.account_status]))
            where_sql = (
                f"{where_sql} AND ({status_predicate})"
                if where_sql else f"WHERE {status_predicate}"
            )
        scope_predicate, scope_parameters = account_scope_sql(
            connection, payload.scope, roster=roster
        )
        where_sql = (
            f"{where_sql} AND ({scope_predicate})"
            if where_sql else f"WHERE {scope_predicate}"
        )
        parameters.extend(scope_parameters)
        archive_total = int(connection.execute("SELECT COUNT(*) FROM accounts").fetchone()[0])
        total = int(
            connection.execute(
                f"SELECT COUNT(*) FROM accounts a {where_sql}", parameters
            ).fetchone()[0]
        )
        account_rows = connection.execute(
            f"""
            SELECT a.* FROM accounts a {where_sql}
            ORDER BY a.updated_at DESC, a.id DESC
            LIMIT ? OFFSET ?
            """,
            [*parameters, payload.page_size, offset],
        ).fetchall()
        items: List[Dict[str, Any]] = []
        for row in account_rows:
            items.append(account_read_model(connection, row, roster=roster, update_frequencies=frequencies))
    return {
        "items": items,
        "total": total,
        "page": payload.page,
        "page_size": payload.page_size,
        "archive_total": archive_total,
        "roster": roster,
    }


_LOCAL_MEDIA_FLAGS_SQL = """
    SELECT DISTINCT e.content_id
    FROM evidence_artifacts e
    WHERE e.content_id IN ({placeholders})
      AND e.status = 'available'
      AND (
        (e.artifact_type IN ('media', 'media_manifest')
          AND (NOT json_valid(e.metadata_json)
               OR json_extract(e.metadata_json, '$.media_lifecycle.bundle_id') IS NULL))
        OR e.artifact_type = 'media_preview_manifest'
        OR (e.artifact_type = 'media_lifecycle_manifest'
          AND json_valid(e.metadata_json)
          AND json_extract(e.metadata_json, '$.media_lifecycle.storage_state') = 'hot'
          AND COALESCE(json_extract(e.metadata_json, '$.media_lifecycle.operation_state'), '')
              NOT IN ('purging', 'restoring'))
      )
"""


_READONLY_PREVIEW_FLAGS_SQL = """
    WITH page_artifacts AS (
        SELECT * FROM evidence_artifacts WHERE content_id IN ({placeholders})
    ), latest_sources AS (
        SELECT content_id, MAX(id) AS id
        FROM page_artifacts WHERE artifact_type = 'media_source'
        GROUP BY content_id
    ), current_controls AS (
        SELECT b.content_id, MAX(b.id) AS id
        FROM page_artifacts b
        JOIN latest_sources s ON s.content_id = b.content_id
        JOIN page_artifacts source ON source.id = s.id
        WHERE b.artifact_type = 'media_lifecycle_manifest'
          AND json_valid(b.metadata_json)
          AND json_extract(b.metadata_json, '$.media_lifecycle.source_artifact_id') = source.id
          AND json_extract(b.metadata_json, '$.media_lifecycle.source_sha256') = source.sha256
        GROUP BY b.content_id
    ), latest_previews AS (
        SELECT p.content_id,
               json_extract(p.metadata_json, '$.media_lifecycle.bundle_id') AS bundle_id,
               MAX(p.id) AS id
        FROM page_artifacts p
        WHERE p.artifact_type = 'media_preview_manifest'
          AND p.status = 'available' AND json_valid(p.metadata_json)
        GROUP BY p.content_id, bundle_id
    )
    SELECT b.content_id
    FROM current_controls current
    JOIN page_artifacts b ON b.id = current.id
    JOIN latest_previews latest ON latest.content_id = b.content_id
      AND latest.bundle_id = json_extract(b.metadata_json, '$.media_lifecycle.bundle_id')
    JOIN page_artifacts p ON p.id = latest.id
    WHERE b.status = 'available'
      AND json_extract(b.metadata_json, '$.media_lifecycle.manifest_sha256') = b.sha256
      AND json_extract(p.metadata_json, '$.media_lifecycle.control_artifact_id') = b.id
      AND json_extract(p.metadata_json, '$.media_lifecycle.manifest_sha256') = b.sha256
      AND p.processor_version = ?
"""


def _content_local_media_flags(
    connection: sqlite3.Connection, content_ids: List[int], *, read_only: bool
) -> set[int]:
    """Project which listed contents have locally viewable media.

    A writer answers from the artifact ledger: legacy originals (rows without
    a lifecycle namespace), retained previews, or managed bundles still hot
    and not being purged or restored.  A read replica never serves managed originals,
    but can serve retained previews bound to the latest source and its current
    bundle.  This is a page-scoped ledger projection without file I/O; evidence
    and file endpoints remain responsible for checking the actual bytes.
    """
    if not content_ids:
        return set()
    placeholders = ",".join("?" * len(content_ids))
    sql = _READONLY_PREVIEW_FLAGS_SQL if read_only else _LOCAL_MEDIA_FLAGS_SQL
    parameters = [*content_ids, media_api.PREVIEW_VERSION] if read_only else content_ids
    rows = connection.execute(
        sql.format(placeholders=placeholders), parameters
    ).fetchall()
    return {int(row[0]) for row in rows}


def _content_search(
    payload: ContentSearchRequest, *, db_path: Path, read_only: bool = False
) -> Dict[str, Any]:
    where: List[str] = [content_statistics_scope_sql("c")]
    parameters: List[Any] = []
    direction_sql = effective_direction_sql()
    if payload.query:
        where.append(
            "(c.link_id LIKE ? OR c.title LIKE ? OR c.raw_account_uid LIKE ? "
            "OR c.raw_account_name LIKE ? OR c.canonical_url LIKE ?)"
        )
        pattern = f"%{payload.query}%"
        parameters.extend([pattern] * 5)
    if payload.platform:
        where.append("c.platform=?")
        parameters.append(payload.platform)
    if payload.account_type:
        where.append("COALESCE(a.account_type, c.legacy_account_type, 'unknown')=?")
        parameters.append(payload.account_type)
    if payload.content_direction:
        where.append(f"{direction_sql}=?")
        parameters.append(payload.content_direction)
    if payload.selling_point == SELLING_POINT_NONE:
        where.append("ev.primary_selling_point_code IS NULL")
    elif payload.selling_point:
        where.append("ev.primary_selling_point_code=?")
        parameters.append(payload.selling_point)
    # SPU/人群/场景 标签筛选：只在 v14 关联域可用时生效（只读副本可能仍是 v13）
    spu_filters: List[str] = []
    spu_parameters: List[Any] = []
    if payload.spu_series == SELLING_POINT_NONE:
        spu_filters.append(
            "NOT EXISTS (SELECT 1 FROM content_spu_links sl WHERE sl.content_id=c.id"
            " AND sl.invalidated_at IS NULL AND sl.is_primary=1)"
        )
    elif payload.spu_series:
        spu_filters.append(
            "EXISTS (SELECT 1 FROM content_spu_links sl JOIN spu_catalog sc2 ON sc2.spu_id=sl.spu_id"
            " WHERE sl.content_id=c.id AND sl.invalidated_at IS NULL AND sl.is_primary=1"
            " AND sc2.series_slug=?)"
        )
        spu_parameters.append(payload.spu_series)
    if payload.audience == SELLING_POINT_NONE:
        spu_filters.append(
            "NOT EXISTS (SELECT 1 FROM content_audience_links al WHERE al.content_id=c.id"
            " AND al.invalidated_at IS NULL)"
        )
    elif payload.audience:
        spu_filters.append(
            "EXISTS (SELECT 1 FROM content_audience_links al WHERE al.content_id=c.id"
            " AND al.invalidated_at IS NULL AND al.audience_code=?)"
        )
        spu_parameters.append(payload.audience)
    if payload.scene == SELLING_POINT_NONE:
        spu_filters.append(
            "NOT EXISTS (SELECT 1 FROM content_scene_links cl WHERE cl.content_id=c.id"
            " AND cl.invalidated_at IS NULL)"
        )
    elif payload.scene:
        spu_filters.append(
            "EXISTS (SELECT 1 FROM content_scene_links cl WHERE cl.content_id=c.id"
            " AND cl.invalidated_at IS NULL AND cl.scene_code=?)"
        )
        spu_parameters.append(payload.scene)
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""
    from_sql = """
        FROM content_items c
        LEFT JOIN accounts a ON a.id=c.account_id
        LEFT JOIN display_effective_evaluations ev ON ev.content_id=c.id
        LEFT JOIN duplicate_relations duplicate ON duplicate.id=(
            SELECT d2.id FROM duplicate_relations d2
            WHERE d2.duplicate_content_id=c.id AND d2.status='confirmed'
            ORDER BY d2.id LIMIT 1
        )
        LEFT JOIN content_items original ON original.id=duplicate.original_content_id
    """
    count_from_parts = ["FROM content_items c"]
    if payload.account_type or payload.content_direction:
        count_from_parts.append("LEFT JOIN accounts a ON a.id=c.account_id")
    if payload.selling_point or payload.content_direction:
        count_from_parts.append(
            "LEFT JOIN display_effective_evaluations ev ON ev.content_id=c.id"
        )
    count_from_sql = " ".join(count_from_parts)
    count_with_sql = (
        f"WITH {DISPLAY_EFFECTIVE_EVALUATIONS_CTE} "
        if payload.selling_point or payload.content_direction
        else ""
    )
    offset = (payload.page - 1) * payload.page_size
    with connect(db_path, read_only=read_only) as connection:
        labels_ready = spu_domain_ready(connection)
        if labels_ready and spu_filters:
            where.extend(spu_filters)
            parameters.extend(spu_parameters)
            where_sql = f"WHERE {' AND '.join(where)}"
        total = int(
            connection.execute(
                f"{count_with_sql}SELECT COUNT(*) {count_from_sql} {where_sql}",
                parameters,
            ).fetchone()[0]
        )
        select_sql = f"""
            SELECT c.id, c.link_id, c.platform, c.platform_content_id,
                   c.canonical_url, c.published_at, c.title, c.body, c.content_type,
                   c.raw_account_uid, c.raw_account_name,
                   COALESCE(a.account_type, c.legacy_account_type, 'unknown') account_type,
                   {direction_sql} content_direction,
                   ev.primary_selling_point_code, ev.evidence_level,
                   ev.content_automotive_score,
                   ev.id display_evaluation_id,
                   ev.release_id evaluation_release_id,
                   COALESCE(ev.evaluation_freshness, 'missing') evaluation_freshness,
                   CASE WHEN ev.evaluation_freshness='stale' THEN 1 ELSE 0 END evaluation_is_stale,
                   original.link_id duplicate_original_link_id
        """
        if payload.selling_point or payload.content_direction:
            rows = connection.execute(
                f"""
                WITH {DISPLAY_EFFECTIVE_EVALUATIONS_CTE}
                {select_sql}
                {from_sql} {where_sql}
                ORDER BY c.published_at IS NULL, c.published_at DESC, c.id DESC
                LIMIT ? OFFSET ?
                """,
                [*parameters, payload.page_size, offset],
            ).fetchall()
        else:
            # Pick the requested page with the publication index before ranking
            # evaluations. Most list reads do not filter on evaluation fields;
            # restricting that CTE to at most one page avoids scanning every
            # historical evaluation merely to render 50 rows.
            rows = connection.execute(
                f"""
                WITH page_ids AS MATERIALIZED (
                    SELECT c.id
                    FROM content_items c
                    LEFT JOIN accounts a ON a.id=c.account_id
                    {where_sql}
                    ORDER BY c.published_at DESC, c.id DESC
                    LIMIT ? OFFSET ?
                ),
                {display_effective_evaluations_cte_for("page_ids")}
                {select_sql}
                FROM page_ids page
                JOIN content_items c ON c.id=page.id
                LEFT JOIN accounts a ON a.id=c.account_id
                LEFT JOIN display_effective_evaluations ev ON ev.content_id=c.id
                LEFT JOIN duplicate_relations duplicate ON duplicate.id=(
                    SELECT d2.id FROM duplicate_relations d2
                    WHERE d2.duplicate_content_id=c.id AND d2.status='confirmed'
                    ORDER BY d2.id LIMIT 1
                )
                LEFT JOIN content_items original ON original.id=duplicate.original_content_id
                ORDER BY c.published_at DESC, c.id DESC
                """,
                [*parameters, payload.page_size, offset],
            ).fetchall()
        items = [dict(row) for row in rows]
        metrics = select_content_metrics(connection, [int(item["id"]) for item in items])
        for item in items:
            selected = metrics.get(int(item["id"]), {})
            for field in ("view_count", "comment_count", "like_count", "share_count", "collect_count"):
                item[field] = selected.get(field)
            item["metrics_captured_at"] = selected.get("captured_at")
            item["metric_fields"] = selected.get("fields", {})
        tag_labels = (
            spu_content_labels(connection, [int(item["id"]) for item in items])
            if labels_ready
            else {}
        )
        media_flags = _content_local_media_flags(
            connection, [int(item["id"]) for item in items], read_only=read_only
        )
    for item in items:
        item["local_media_available"] = int(item["id"]) in media_flags
        entry = tag_labels.get(int(item["id"])) or {
            "spu": None,
            "spu_secondary_count": 0,
            "spu_gray_count": 0,
            "audience": None,
            "scenes": [],
        }
        item["spu"] = entry["spu"]
        item["spu_secondary_count"] = entry["spu_secondary_count"]
        item["spu_gray_count"] = entry["spu_gray_count"]
        item["audience"] = entry["audience"]
        item["scenes"] = entry["scenes"]
    # Freshness verifies and hashes archived scan receipts; keep that proof on
    # operational endpoints instead of repeating it for every list page.
    return {
        "items": items,
        "total": total,
        "page": payload.page,
        "page_size": payload.page_size,
    }


_SELLING_POINT_STAT_CHANNELS = ("douyin", "xiaohongshu")
_SELLING_POINT_STAT_SCENES = ("used_car", "new_car", "media")
def _selling_point_window_stats(
    connection: sqlite3.Connection,
) -> tuple[Dict[str, Any], Dict[str, Dict[str, Any]]]:
    """Per-window selling point hit/exposure stats plus scene/channel denominators.

    Windows reuse the overview boundaries (Asia/Shanghai). Count denominators are
    all publications in the window; exposure denominators only include contents
    with a positive latest view_count snapshot (valid exposure), mirroring the
    overview conclusion rules.
    """

    direction_sql = effective_direction_sql()
    windows_meta: Dict[str, Any] = {}
    point_windows: Dict[str, Dict[str, Any]] = {}
    for window_key, (start, end) in _windows().items():
        start_utc, end_utc = _utc_text(start), _utc_text(end)
        scene_denominators: Dict[str, Any] = {
            scene: {
                channel: {"publication_count": 0, "valid_exposure_views": 0}
                for channel in _SELLING_POINT_STAT_CHANNELS
            }
            for scene in _SELLING_POINT_STAT_SCENES
        }
        # Keep indexed evaluation lookups; select metric facts once per window,
        # using the same provider/cutoff rules as content pages and reports.
        denominator_rows = connection.execute(
            f"""
            SELECT c.id, {direction_sql} direction, c.platform
            FROM content_items c
            LEFT JOIN accounts a ON a.id=c.account_id
            LEFT JOIN evaluation_versions ev ON ev.id=(
                SELECT ev2.id FROM evaluation_versions ev2
                WHERE ev2.content_id=c.id
                  AND ev2.release_id=(
                    SELECT id FROM evaluation_releases WHERE status='active'
                  )
                  AND ev2.invalidated_at IS NULL
                ORDER BY ev2.evaluated_at DESC, ev2.id DESC LIMIT 1
            )
            WHERE c.published_at >= ? AND c.published_at < ?
                  AND {content_statistics_scope_sql("c")}
            """,
            (start_utc, end_utc),
        ).fetchall()
        metric_values = select_content_metrics(
            connection,
            [int(row["id"]) for row in denominator_rows],
            metric_fields=("view_count",),
        )

        def valid_views(content_id: int) -> int:
            return max(0, int(metric_values.get(content_id, {}).get("view_count") or 0))

        for row in denominator_rows:
            scene, channel = str(row["direction"]), str(row["platform"])
            if (
                scene not in scene_denominators
                or channel not in _SELLING_POINT_STAT_CHANNELS
            ):
                continue
            scene_denominators[scene][channel]["publication_count"] += 1
            scene_denominators[scene][channel]["valid_exposure_views"] += valid_views(int(row["id"]))
        windows_meta[window_key] = {
            "period_start": start.isoformat(),
            "period_end": end.isoformat(),
            "scene_denominators": scene_denominators,
        }
        hit_rows = connection.execute(
            f"""
            WITH {FORMAL_CURRENT_EVALUATIONS_CTE},
            matched AS (
                SELECT DISTINCT em.selling_point_code code, em.scene, em.match_role,
                       ev.content_id, c.platform
                FROM formal_current_evaluations ev
                JOIN evaluation_matches em ON em.evaluation_id=ev.id
                JOIN content_items c ON c.id=ev.content_id
                WHERE c.published_at >= ? AND c.published_at < ?
                  AND {content_statistics_scope_sql("c")}
            )
            SELECT m.code, m.scene, m.platform, m.match_role, m.content_id
            FROM matched m
            """,
            (start_utc, end_utc),
        ).fetchall()
        hit_groups: Dict[tuple[str, str, str], Dict[str, set[int]]] = {}
        for row in hit_rows:
            key = (str(row["code"]), str(row["scene"]), str(row["platform"]))
            group = hit_groups.setdefault(key, {"primary": set(), "all": set()})
            group["all"].add(int(row["content_id"]))
            if row["match_role"] == "primary":
                group["primary"].add(int(row["content_id"]))
        for (code, scene, channel), group in hit_groups.items():
            if scene not in _SELLING_POINT_STAT_SCENES:
                continue
            scene_map = point_windows.setdefault(code, {}).setdefault(
                window_key, {}
            )
            entry = scene_map.setdefault(
                scene,
                {
                    "primary_hits": 0,
                    "total_hits": 0,
                    "channels": {
                        key: {"primary_hits": 0, "primary_views": 0}
                        for key in _SELLING_POINT_STAT_CHANNELS
                    },
                },
            )
            entry["primary_hits"] += len(group["primary"])
            entry["total_hits"] += len(group["all"])
            if channel in entry["channels"]:
                entry["channels"][channel] = {
                    "primary_hits": len(group["primary"]),
                    "primary_views": sum(valid_views(cid) for cid in group["primary"]),
                }
    return windows_meta, point_windows


def _selling_point_list(*, db_path: Path, read_only: bool = False) -> Dict[str, Any]:
    with connect(db_path, read_only=read_only) as connection:
        taxonomies = connection.execute(
            """
            SELECT * FROM taxonomy_versions WHERE status='published'
            ORDER BY published_at, created_at, id
            """
        ).fetchall()
        if not taxonomies:
            return {"taxonomy": None, "items": []}
        if len(taxonomies) != 1:
            raise TaxonomyError("multiple published taxonomies exist")
        taxonomy = taxonomies[0]
        try:
            release = active_release(connection)
        except EvaluationSelectorError as error:
            raise TaxonomyError(str(error)) from error
        assert release is not None
        if str(release["taxonomy_version"]) != str(taxonomy["version"]):
            raise TaxonomyError(
                "active evaluation release does not match published taxonomy"
            )
        rows = connection.execute(
            f"""
            WITH {FORMAL_CURRENT_EVALUATIONS_CTE},
            resolved_matches AS (
                SELECT em.selling_point_code, em.match_role, ev.content_id,
                       em.scene
                FROM formal_current_evaluations ev
                JOIN evaluation_matches em ON em.evaluation_id=ev.id
                JOIN content_items c ON c.id=ev.content_id
                WHERE {content_statistics_scope_sql("c")}
            )
            SELECT sp.*,
                   COUNT(DISTINCT CASE WHEN rm.match_role='primary' THEN rm.content_id END) primary_hits,
                   COUNT(DISTINCT rm.content_id) total_hits,
                   COUNT(DISTINCT CASE WHEN rm.scene='used_car' AND rm.match_role='primary' THEN rm.content_id END) used_car_primary_hits,
                   COUNT(DISTINCT CASE WHEN rm.scene='used_car' THEN rm.content_id END) used_car_total_hits,
                   COUNT(DISTINCT CASE WHEN rm.scene='new_car' AND rm.match_role='primary' THEN rm.content_id END) new_car_primary_hits,
                   COUNT(DISTINCT CASE WHEN rm.scene='new_car' THEN rm.content_id END) new_car_total_hits,
                   COUNT(DISTINCT CASE WHEN rm.scene='media' AND rm.match_role='primary' THEN rm.content_id END) media_primary_hits,
                   COUNT(DISTINCT CASE WHEN rm.scene='media' THEN rm.content_id END) media_total_hits
            FROM selling_points sp
            LEFT JOIN resolved_matches rm ON rm.selling_point_code=sp.code
            WHERE sp.taxonomy_id=?
            GROUP BY sp.id
            ORDER BY substr(sp.code, 1, 1), CAST(substr(sp.code, 2) AS INTEGER)
            """,
            (taxonomy["id"],),
        ).fetchall()
        windows_meta, point_windows = _selling_point_window_stats(connection)
        items: List[Dict[str, Any]] = []
        for row in rows:
            point = serialize_point_row(connection, taxonomy, row)
            items.append(
                {
                    **point,
                    "enabled": bool(row["enabled"]),
                    "primary_hits": row["primary_hits"],
                    "total_hits": row["total_hits"],
                    "window_hits": point_windows.get(str(row["code"]), {}),
                    "scene_hits": {
                        scene: {
                            "primary_hits": row[f"{scene}_primary_hits"],
                            "total_hits": row[f"{scene}_total_hits"],
                        }
                        for scene in ("used_car", "new_car", "media")
                    },
                }
            )
    return {
        "taxonomy": {
            "id": taxonomy["id"],
            "version": taxonomy["version"],
            "status": taxonomy["status"],
            "published_at": taxonomy["published_at"],
        },
        "windows": windows_meta,
        "items": items,
    }


def _read_local_json(local_path: str) -> Dict[str, Any]:
    path = _safe_project_path(local_path)
    if not path.is_file() or path.suffix.lower() != ".json":
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _replica_artifact_path(value: str, *, read_only: bool) -> Path:
    from .artifact_paths import installed_snapshot
    if read_only and installed_snapshot() is not None:
        # A v2 receipt provides one exact writer root and allowlist. Never use
        # the legacy suffix heuristic to borrow an unlisted same-name file.
        return _safe_project_path(value)
    try:
        return _safe_project_path(value)
    except HTTPException:
        if not read_only or not Path(value).is_absolute():
            raise
        normalized = value.replace("\\", "/")
        for marker in ("/data/cache/", "/reports/"):
            if marker in normalized:
                suffix = normalized.split(marker, 1)[1]
                return _safe_project_path(marker.strip("/") + "/" + suffix)
        raise


def _artifact_media_paths(
    row: sqlite3.Row, *, read_only: bool = False
) -> List[Optional[Path]]:
    try:
        path = _replica_artifact_path(str(row["local_path"]), read_only=read_only)
    except (HTTPException, OSError):
        return []
    if path.suffix.lower() != ".json":
        if not path.is_file():
            return []
        if read_only:
            expected_sha = str(row["sha256"] or "")
            expected_size = row["byte_size"]
            try:
                metadata = path.stat()
                if re.fullmatch(r"[0-9a-f]{64}", expected_sha) is None:
                    return []
                if expected_size is not None and metadata.st_size != int(
                    expected_size
                ):
                    return []
                if (
                    _cached_file_sha256(
                        str(path), metadata.st_size, metadata.st_mtime_ns
                    )
                    != expected_sha
                ):
                    return []
            except OSError:
                return []
        return [path]
    # Legacy media manifests do not register per-child hashes in SQLite. The
    # read replica must not serve a same-path but stale child file as evidence.
    if read_only:
        return []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return []
    if not isinstance(value, dict):
        return []
    candidates: List[str] = []
    if value.get("video_path"):
        candidates.append(str(value["video_path"]))
    candidates.extend(
        str(item) for item in value.get("image_paths", []) if isinstance(item, str)
    )
    paths: List[Optional[Path]] = []
    for candidate in candidates:
        try:
            resolved = _replica_artifact_path(candidate, read_only=read_only)
            paths.append(resolved if resolved.is_file() else None)
        except (HTTPException, OSError):
            paths.append(None)
    return paths


def _ocr_payload_text(payload: Dict[str, Any]) -> str:
    combined = str(payload.get("combined_text") or "").strip()
    if combined:
        return combined
    texts: List[str] = []
    observations = payload.get("observations")
    if not isinstance(observations, list):
        return ""
    for item in observations:
        if not isinstance(item, dict):
            continue
        text = "\n".join(str(item.get("text") or "").splitlines()).strip()
        if text and text not in texts:
            texts.append(text)
    return "\n".join(texts)


def _friendly_media_processing_error(value: Any) -> Optional[str]:
    if not value:
        return None
    message = str(value).lower()
    if "no frames were extracted" in message:
        return "没有从视频中成功截取画面，请重新处理媒体。"
    if any(
        marker in message
        for marker in ("httperror", "urlerror", "remotedisconnected")
    ):
        return "图片或视频下载失败，可能是链接失效或网络异常，请稍后重试。"
    if "logical image group" in message or "image download incomplete" in message:
        return "部分图片下载失败，请重新处理媒体。"
    if "not a playable video" in message:
        return "下载到的视频无法播放，请重新获取媒体后再试。"
    if "stale running slot recovered" in message:
        return "上次处理被中断，系统已恢复，可以重新处理。"
    return "媒体处理没有完成，请重新尝试；如果一直失败，请联系管理员。"


def _content_evidence(
    content_id: int, *, db_path: Path, read_only: bool = False
) -> Dict[str, Any]:
    with connect(db_path, read_only=read_only) as connection:
        content = connection.execute(
            "SELECT * FROM content_items WHERE id=?", (content_id,)
        ).fetchone()
        if content is None:
            raise HTTPException(
                status_code=404, detail="这条内容已不存在，请刷新列表。"
            )
        evaluation = display_effective_evaluation(connection, content_id)
        artifact_rows = connection.execute(
            """
            SELECT * FROM evidence_artifacts
            WHERE content_id=? AND status='available'
            ORDER BY id DESC
            """,
            (content_id,),
        ).fetchall()
        latest: Dict[str, sqlite3.Row] = {}
        for row in artifact_rows:
            latest.setdefault(str(row["artifact_type"]), row)
        media_row = next(
            (latest[kind] for kind in ("media", "media_manifest") if kind in latest),
            None,
        )
        asr_row = next(
            (
                latest[kind]
                for kind in ("asr", "transcript", "media_transcript")
                if kind in latest
            ),
            None,
        )
        ocr_row = next(
            (latest[kind] for kind in ("ocr", "media_ocr") if kind in latest),
            None,
        )
        comment_version = connection.execute(
            """
            SELECT * FROM comment_evidence_versions
            WHERE content_id=? ORDER BY captured_at DESC, id DESC LIMIT 1
            """,
            (content_id,),
        ).fetchone()
        comment_rows = (
            []
            if comment_version is None
            else connection.execute(
                """
            SELECT body, like_count, published_at FROM comments
            WHERE evidence_version_id=?
            ORDER BY COALESCE(like_count,0) DESC, id LIMIT 20
            """,
                (comment_version["id"],),
            ).fetchall()
        )
        stored_comment_count = (
            0
            if comment_version is None
            else int(
                connection.execute(
                    "SELECT COUNT(*) FROM comments WHERE evidence_version_id=?",
                    (comment_version["id"],),
                ).fetchone()[0]
            )
        )
        processing = connection.execute(
            """
            SELECT id,processor_type,processor_version,status,attempt_count,
                   error_message,updated_at
            FROM media_processing_slots WHERE content_id=?
            ORDER BY updated_at DESC,id DESC
            """,
            (content_id,),
        ).fetchall()
        managed = media_api.managed_evidence(connection, content_id, read_only=read_only)
    media_items: List[Dict[str, Any]] = []
    media_availability = {
        "status": "missing",
        "reason": "还没有可查看的图片或视频。",
    }
    if media_row is not None and managed is None:
        media_paths = _artifact_media_paths(media_row, read_only=read_only)
        for index, path in enumerate(media_paths):
            if path is None:
                continue
            suffix = path.suffix.lower()
            media_items.append(
                {
                    "artifact_id": int(media_row["id"]),
                    "index": index,
                    "kind": "video"
                    if suffix in {".mp4", ".mov", ".m4v", ".webm"}
                    else "image",
                    "name": path.name,
                    "url": f"/api/v8/contents/{content_id}/evidence/files/{media_row['id']}/{index}",
                }
            )
        if any(path is not None for path in media_paths):
            media_availability = {"status": "available", "reason": ""}
        elif read_only:
            media_availability = {
                "status": "omitted",
                "reason": "线上版本没有包含这张图片或视频，当前无法查看。请回到本地重新处理并发布。",
            }
        else:
            media_availability = {
                "status": "missing",
                "reason": "本地图片或视频文件丢失，请重新处理媒体。",
            }
    asr_payload = _read_local_json(str(asr_row["local_path"])) if asr_row and managed is None else {}
    ocr_payload = _read_local_json(str(ocr_row["local_path"])) if ocr_row and managed is None else {}
    if managed is not None:
        media_items = managed["media"]
        media_availability = managed["media_availability"]
        asr_payload = managed["asr_payload"]
        ocr_payload = managed["ocr_payload"]
    evaluation_payload = (
        json.loads(str(evaluation["payload_json"])) if evaluation is not None else None
    )
    return {
        "content": {
            key: content[key]
            for key in (
                "id",
                "link_id",
                "platform",
                "canonical_url",
                "title",
                "body",
                "content_type",
                "published_at",
                "raw_account_uid",
                "raw_account_name",
            )
        },
        "display_evaluation_id": int(evaluation["id"])
        if evaluation is not None
        else None,
        "evaluation_freshness": str(evaluation["evaluation_freshness"])
        if evaluation is not None
        else "missing",
        "evaluation_is_stale": evaluation["evaluation_freshness"] == "stale"
        if evaluation is not None
        else False,
        "evaluation": evaluation_payload,
        "media": media_items,
        "media_availability": media_availability,
        "previews": managed["previews"] if managed is not None else [],
        "media_lifecycle": managed["media_lifecycle"] if managed is not None else None,
        "read_only": read_only,
        "asr": {
            "status": asr_payload.get("status")
            or ("missing" if asr_row is None else "available"),
            "model": asr_payload.get("model"),
            "text": asr_payload.get("text") or "",
        },
        "ocr": {
            "status": ocr_payload.get("status")
            or ("missing" if ocr_row is None else "available"),
            "observation_count": ocr_payload.get("ocr_observation_count")
            or ocr_payload.get("source_count")
            or 0,
            "text": _ocr_payload_text(ocr_payload),
        },
        "comments": {
            "status": str(comment_version["status"]) if comment_version else "missing",
            "captured_at": comment_version["captured_at"] if comment_version else None,
            "declared_count": comment_version["comment_count"]
            if comment_version
            else None,
            "stored_count": stored_comment_count,
            "top_items": [dict(row) for row in comment_rows],
        },
        "processing_slots": [
            {
                **dict(row),
                "error_message": _friendly_media_processing_error(row["error_message"]),
            }
            for row in processing
        ],
    }


def _recover_interrupted_tasks(*, db_path: Path) -> int:
    with connect(db_path) as connection:
        cursor = connection.execute(
            """
            UPDATE report_tasks
            SET task_status='interrupted', message='服务重启，任务已中断，可重试', updated_at=?
            WHERE task_status IN ('running','cancel_requested')
            """,
            (now_utc(),),
        )
        connection.commit()
        return int(cursor.rowcount)


def _run_startup_catchup(
    app: FastAPI,
    *,
    db_path: Path,
    reports_root: Path,
    effective_from: date | None = None,
) -> None:
    """Run report-only catch-up without blocking API startup."""
    try:
        results = startup_catchup(
            db_path=db_path, reports_root=reports_root,
            effective_from=effective_from,
        )
    except Exception as exc:
        LOGGER.exception("startup catch-up failed")
        app.state.catchup_error = str(exc)
        app.state.catchup_status = "failed"
    else:
        app.state.catchup_results = results
        statuses = {str(item.get("status") or "") for item in results}
        if "failed" in statuses:
            app.state.catchup_status = "failed"
        elif statuses.intersection({"deferred", "skipped_duplicate"}):
            app.state.catchup_status = "deferred"
        elif statuses <= {
            "succeeded",
            "partial",
            "skipped",
        }:
            app.state.catchup_status = "succeeded"
        else:
            app.state.catchup_status = "failed"


@contextmanager
def _writer_process_lock(path: Path, *, enabled: bool):
    """Hold a checkout-local lock for an explicitly isolated runtime."""

    if not enabled:
        yield None
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise RuntimeError(f"writer lock path must not be a symlink: {path}")
    descriptor = os.open(path, os.O_CREAT | os.O_RDWR | os.O_CLOEXEC, 0o600)
    lease: WriterLockLease | None = None
    try:
        identity = FileIdentity.from_stat(os.fstat(descriptor))
        current = path.stat()
        if not os.path.samestat(os.fstat(descriptor), current):
            raise RuntimeError(f"writer lock identity changed: {path}")
        lease = WriterLockLease(path=path.resolve(strict=True), identity=identity)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError(
                f"another Dcar scheduler already holds the writer lock: {path}"
            ) from exc
        os.ftruncate(descriptor, 0)
        os.write(descriptor, f"pid={os.getpid()}\n".encode("ascii"))
        os.fsync(descriptor)
        yield lease
    finally:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)


def _open_sqlite_runtime_anchor(path: Path) -> sqlite3.Connection:
    """Keep writable WAL sidecars attached for the API process lifetime."""

    connection = connect(path, read_only=False)
    try:
        connection.execute("PRAGMA query_only = ON")
        journal_mode = str(
            connection.execute("PRAGMA journal_mode").fetchone()[0]
        ).lower()
        if journal_mode != "wal":
            raise RuntimeError("writable runtime SQLite anchor requires WAL mode")
        if connection.in_transaction:
            raise RuntimeError("writable runtime SQLite anchor must remain idle")
        return connection
    except BaseException:
        connection.close()
        raise


def _uses_formal_database(path: Path) -> bool:
    """Return whether one runtime points at the checked-out formal database."""

    return is_formal_database_path(path, formal_database=DEFAULT_DB)


def _resolve_runtime_access_before_database(
    config: ApiConfig,
) -> ResolvedDatabaseAccess | None:
    """Resolve environment-backed capabilities before SQLite or mkdir calls."""

    mode = config.runtime_access_mode
    if config.read_only:
        if mode not in {None, DatabaseAccessMode.FORMAL_READ}:
            raise RuntimeError("read-only replica requires formal_read access")
        return resolve_read_only_replica(config.db_path)
    if mode is DatabaseAccessMode.FORMAL_READ:
        raise RuntimeError("formal_read access requires read-only API mode")
    if mode in {DatabaseAccessMode.WRITER, DatabaseAccessMode.FORMAL_MUTATION}:
        try:
            access = resolve_installed_database_access(
                mode,
                database=config.db_path,
                project_root=config.project_root,
            )
        except (OSError, RuntimeDatabaseError, ValueError) as error:
            raise RuntimeError(f"installed runtime database refused: {error}") from error
        if access.writer_lock is None or (
            config.writer_lock.expanduser().resolve(strict=False)
            != access.writer_lock.resolve(strict=False)
        ):
            raise RuntimeError("ApiConfig writer lock differs from installed runtime")
        return access
    if mode is DatabaseAccessMode.ISOLATED_CANDIDATE:
        try:
            return resolve_isolated_candidate(config.db_path)
        except (OSError, RuntimeDatabaseError, ValueError) as error:
            raise RuntimeError(f"installed runtime database refused: {error}") from error
    if mode is None and config.db_path.exists():
        try:
            if is_installed_formal_database(config.db_path, required=False):
                raise RuntimeError(
                    "installed writer database requires an explicit writer access mode"
                )
        except RuntimeDatabaseError as error:
            raise RuntimeError(f"installed runtime database refused: {error}") from error
    if mode is None and config.runtime_from_environment:
        raise RuntimeError(
            "formal_database_identity_unresolved: set the installed writer/read-only "
            "contract or explicitly select DCAR_V8_ISOLATED_CANDIDATE=1"
        )
    return None


@contextmanager
def _runtime_writer_lock(
    config: ApiConfig,
    access: ResolvedDatabaseAccess | None,
):
    if access is not None and access.access_mode in {
        DatabaseAccessMode.WRITER,
        DatabaseAccessMode.FORMAL_MUTATION,
    }:
        with acquire_writer_lock(access) as lease:
            yield lease
        return
    with _writer_process_lock(
        config.writer_lock,
        enabled=bool(config.scheduler_enabled and not config.read_only),
    ) as lease:
        yield lease


@asynccontextmanager
async def _lifespan_runtime(app: FastAPI):
    config = getattr(app.state, "config", None)
    if not isinstance(config, ApiConfig):
        raise RuntimeError("FastAPI application is missing ApiConfig")
    if config.read_only and (
        config.scheduler_enabled or config.startup_catchup_enabled
    ):
        raise RuntimeError(
            "read-only replica cannot enable scheduler or startup catch-up"
        )
    if config.read_only:
        if not config.db_path.is_file():
            raise RuntimeError(
                f"read-only replica database is missing: {config.db_path}"
            )
        with connect(config.db_path, read_only=True) as connection:
            require_schema_compatibility(
                connection, supported_versions=frozenset({SCHEMA_VERSION})
            )
            connection.execute("SELECT 1 FROM content_items LIMIT 1").fetchone()
        app.state.database_sha256 = _file_sha256(config.db_path)
        from .artifact_paths import installed_snapshot
        installed = installed_snapshot()
        if installed is not None:
            with connect(config.db_path, read_only=True) as connection:
                identity = _database_state(connection)["runtime_identity"]
            receipt = installed["receipt"]
            if (receipt.get("database_sha256", {}).get("dcar_insight.sqlite3") != app.state.database_sha256
                    or receipt.get("runtime_identity") != identity):
                raise RuntimeError("installed snapshot does not bind the read-only database")
        app.state.recovered_fetch_slots = {
            "stale_candidates": 0,
            "recovered": 0,
            "skipped": "read_only",
        }
        app.state.recovered_media_slots = {
            "stale_candidates": 0,
            "recovered": 0,
            "retryable_failed": 0,
            "terminal_failed": 0,
            "cas_conflicts": 0,
            "exhausted_normalized": 0,
            "skipped": "read_only",
        }
        app.state.recovered_tasks = 0
        app.state.recovered_scheduler_runs = 0
    else:
        if config.runtime_access_mode in {
            DatabaseAccessMode.WRITER,
            DatabaseAccessMode.FORMAL_MUTATION,
        } or _uses_formal_database(config.db_path):
            if not config.db_path.is_file():
                raise RuntimeError(
                    f"formal SQLite database is missing: {config.db_path}"
                )
            # The formal database is migrated only by the explicit offline
            # migration command.  Runtime startup must fail closed without
            # opening a writable SQLite connection (which would create WAL/
            # SHM sidecars before a schema mismatch can be reported).
            with connect(config.db_path, read_only=True) as connection:
                try:
                    require_schema_compatibility(
                        connection,
                        supported_versions=frozenset({SCHEMA_VERSION}),
                    )
                except RuntimeError as exc:
                    raise RuntimeError(
                        "formal database schema is incompatible; "
                        "offline schema migration is required: "
                        f"{exc}"
                    ) from exc
        else:
            # Existing local databases obey the same explicit-upgrade rule as
            # the writer.  Validate before opening a writable connection so a
            # rejected historical database does not gain WAL/SHM sidecars.
            if config.db_path.is_file() and config.db_path.stat().st_size:
                with connect(config.db_path, read_only=True) as connection:
                    has_tables = connection.execute(
                        "SELECT 1 FROM sqlite_master WHERE type='table' LIMIT 1"
                    ).fetchone()
                    if has_tables is not None:
                        try:
                            require_schema_compatibility(
                                connection,
                                supported_versions=frozenset({SCHEMA_VERSION}),
                            )
                        except RuntimeError as exc:
                            raise RuntimeError(
                                "existing database schema is incompatible; "
                                "offline schema migration is required: "
                                f"{exc}"
                            ) from exc
            with connect(config.db_path) as connection:
                initialize_database(connection, allow_migrations=False)
        app.state.sqlite_runtime_anchor = _open_sqlite_runtime_anchor(
            config.db_path
        )
        app.state.recovered_scheduler_runs = recover_interrupted_scheduler_runs(
            db_path=config.db_path
        )
        app.state.recovered_fetch_slots = recover_stale_fetch_slots(
            db_path=config.db_path
        )
        app.state.recovered_media_slots = recover_stale_media_processing_slots(
            db_path=config.db_path,
            processor_version_by_type=processor_versions(),
        )
        app.state.recovered_tasks = _recover_interrupted_tasks(db_path=config.db_path)
        app.state.recovered_association_runs = recover_orphan_association_runs(
            db_path=config.db_path
        )
        app.state.database_sha256 = None
    app.state.scheduler_requested = config.scheduler_enabled
    app.state.scheduler_enabled = False
    app.state.startup_catchup_requested = config.startup_catchup_enabled
    app.state.startup_catchup_enabled = False
    app.state.pipeline_reconcile_enabled = False
    app.state.report_runtime_ready = None
    app.state.report_runtime_error = None
    scheduler: Optional[BackgroundScheduler] = None
    if config.scheduler_enabled:
        try:
            with connect(config.db_path) as connection:
                assert_report_runtime_ready(connection)
        except Exception as exc:
            LOGGER.error(
                "automatic report jobs blocked by report runtime gate: %s", exc
            )
            app.state.report_runtime_ready = False
            app.state.report_runtime_error = str(exc)
        else:
            app.state.report_runtime_ready = True
    if config.scheduler_enabled:
        reconcile_effective_date = config.effective_daily_capture_reconcile_from
        if reconcile_effective_date is None:
            raise RuntimeError(
                "daily capture reconcile requires an effective date when "
                "scheduler is enabled"
            )
        scheduler = BackgroundScheduler(
            timezone="Asia/Shanghai",
            executors={
                "default": {"type": "threadpool", "max_workers": 20},
                "control": {"type": "threadpool", "max_workers": 8},
                "report": {"type": "threadpool", "max_workers": 1},
                "reconcile": {"type": "threadpool", "max_workers": 1},
            },
        )
        install_jobs(
            scheduler,
            db_path=config.db_path,
            reports_root=config.reports_root,
            capture_call_override=None,
            reconcile_effective_date=reconcile_effective_date,
        )
        if config.scheduler_start_paused:
            scheduler.start(paused=True)
        else:
            scheduler.start()
        app.state.scheduler_enabled = True
        app.state.pipeline_reconcile_enabled = True
    if config.effective_startup_catchup_enabled:
        app.state.startup_catchup_enabled = True
        app.state.catchup_status = "running"
        app.state.catchup_results = []
        app.state.catchup_error = None
        catchup_thread = threading.Thread(
            target=_run_startup_catchup,
            args=(app,),
            kwargs={
                "db_path": config.db_path,
                "reports_root": config.reports_root,
                "effective_from": config.effective_daily_capture_reconcile_from,
            },
            name="dcar-startup-catchup",
            daemon=True,
        )
        app.state.catchup_thread = catchup_thread
        catchup_thread.start()
    else:
        app.state.catchup_status = "disabled"
        app.state.catchup_results = []
        app.state.catchup_error = None
    app.state.scheduler = scheduler
    try:
        yield
    finally:
        if scheduler is not None:
            scheduler.shutdown(wait=False)


def _current_hold_mirror_root(config: ApiConfig) -> Path:
    configured = os.environ.get("DCAR_CURRENT_HOLD_MIRROR_ROOT", "").strip()
    if configured:
        return Path(configured).expanduser().resolve(strict=False)
    return config.db_path.expanduser().resolve(strict=False).parent / "current-hold-control"


def _drain_current_hold_control(
    *, request_app: FastAPI, config: ApiConfig
) -> dict[str, int]:
    """Drain bounded command batches until one batch proves the queue is short."""

    total = 0
    batches = 0
    while True:
        control_lock = request_app.state.current_hold_control_lock
        with control_lock:
            batch_generation = int(
                getattr(request_app.state, "current_hold_control_wake_generation", 0)
            )
        batch = process_current_activation_hold_commands(
            db_path=config.db_path,
            mirror_root=_current_hold_mirror_root(config),
            limit=10,
            scheduler=getattr(request_app.state, "scheduler", None),
        )
        count = batch.get("count")
        if type(count) is not int or count < 0 or count > 10:
            raise RuntimeError(
                "current-hold control executor returned an invalid batch count"
            )
        total += count
        batches += 1
        with control_lock:
            latest_generation = int(
                getattr(request_app.state, "current_hold_control_wake_generation", 0)
            )
        # A short batch proves the queue was exhausted at that instant. If a
        # POST committed while the batch was running, take another bounded pass
        # before handing the worker back to the executor.
        if count < 10 and latest_generation == batch_generation:
            return {
                "count": total,
                "batches": batches,
                "wake_generation": latest_generation,
            }


def _submit_current_hold_control(*, request_app: FastAPI) -> Future[Any]:
    executor = getattr(request_app.state, "current_hold_control_executor", None)
    if not isinstance(executor, ThreadPoolExecutor) or not bool(
        getattr(request_app.state, "writer_lock_held", False)
    ):
        raise RuntimeError("current-hold control executor has no writer lock")
    config = getattr(request_app.state, "config", None)
    if not isinstance(config, ApiConfig):
        raise RuntimeError("current-hold control executor has no ApiConfig")
    control_lock = request_app.state.current_hold_control_lock
    with control_lock:
        generation = (
            int(getattr(request_app.state, "current_hold_control_wake_generation", 0))
            + 1
        )
        request_app.state.current_hold_control_wake_generation = generation
        existing = getattr(request_app.state, "current_hold_control_future", None)
        if isinstance(existing, Future) and not existing.done():
            return existing
        future = executor.submit(
            _drain_current_hold_control,
            request_app=request_app,
            config=config,
        )
        request_app.state.current_hold_control_future = future
        futures = getattr(request_app.state, "current_hold_control_futures", None)
        if not isinstance(futures, set):
            futures = set()
            request_app.state.current_hold_control_futures = futures
        futures.add(future)

    def completed(item: Future[Any]) -> None:
        drained_generation = generation
        try:
            result = item.result()
            if (
                isinstance(result, Mapping)
                and type(result.get("wake_generation")) is int
            ):
                drained_generation = int(result["wake_generation"])
        except Exception:
            LOGGER.exception("current-hold control executor failed")
        resubmit = False
        with control_lock:
            futures.discard(item)
            if getattr(request_app.state, "current_hold_control_future", None) is item:
                request_app.state.current_hold_control_future = None
                resubmit = bool(
                    getattr(request_app.state, "writer_lock_held", False)
                    and getattr(
                        request_app.state, "current_hold_control_executor", None
                    )
                    is executor
                    and int(
                        getattr(
                            request_app.state,
                            "current_hold_control_wake_generation",
                            0,
                        )
                    )
                    > drained_generation
                )
        if resubmit:
            try:
                _submit_current_hold_control(request_app=request_app)
            except RuntimeError:
                LOGGER.exception("current-hold control executor resubmit failed")

    future.add_done_callback(completed)
    return future


@asynccontextmanager
async def lifespan(app: FastAPI):
    config = getattr(app.state, "config", None)
    if not isinstance(config, ApiConfig):
        raise RuntimeError("FastAPI application is missing ApiConfig")
    # Validate before the freeze check, writer-lock context, or any database
    # access so an impossible reconcile setting cannot leave runtime sidecars.
    app.state.sqlite_runtime_anchor = None
    config.validate_daily_capture_reconcile_contract()
    access = _resolve_runtime_access_before_database(config)
    formal_runtime = bool(
        access is not None
        and access.access_mode
        in {DatabaseAccessMode.WRITER, DatabaseAccessMode.FORMAL_MUTATION}
    ) or _uses_formal_database(config.db_path)
    if formal_runtime and config.operator_freeze_lock.exists():
        # Check the operator freeze before the scheduler lock context: entering
        # that context creates/truncates the lock file even when DB startup is
        # subsequently rejected.
        raise RuntimeError(
            "production startup blocked by operator freeze lock: "
            f"{config.operator_freeze_lock}"
        )
    lock_path = access.writer_lock if access is not None else config.writer_lock
    app.state.writer_lock_path = str(lock_path) if lock_path is not None else None
    app.state.writer_lock_held = False
    app.state.writer_lock = {
        "path": app.state.writer_lock_path,
        "device": None,
        "inode": None,
        "held": False,
    }
    app.state.runtime_database_identity = (
        access.health_identity() if access is not None else None
    )
    with _runtime_writer_lock(config, access) as writer_lease:
        control_executor: ThreadPoolExecutor | None = None
        app.state.current_hold_control_executor = None
        app.state.current_hold_control_future = None
        app.state.current_hold_control_wake_generation = 0
        app.state.current_hold_control_futures = set()
        if writer_lease is not None:
            app.state.writer_lock = writer_lease.health_identity(held=True)
            app.state.writer_lock_held = True
            control_executor = ThreadPoolExecutor(
                max_workers=1, thread_name_prefix="dcar-current-hold-control"
            )
            app.state.current_hold_control_executor = control_executor
        heartbeat_task: asyncio.Task[None] | None = None
        try:
            async with _lifespan_runtime(app):
                if access is None:
                    try:
                        resolved = (
                            resolve_isolated_candidate(config.db_path)
                            if config.runtime_access_mode
                            is DatabaseAccessMode.ISOLATED_CANDIDATE
                            else resolve_isolated_fixture(config.db_path)
                        )
                    except (OSError, RuntimeDatabaseError) as error:
                        raise RuntimeError(
                            f"isolated runtime database refused: {error}"
                        ) from error
                    app.state.runtime_database_identity = resolved.health_identity()
                if writer_lease is not None:
                    app.state.writer_heartbeat_at = now_utc()

                    async def heartbeat() -> None:
                        while bool(getattr(app.state, "writer_lock_held", False)):
                            app.state.writer_heartbeat_at = now_utc()
                            await asyncio.sleep(WRITER_HEARTBEAT_INTERVAL_SECONDS)

                    heartbeat_task = asyncio.create_task(
                        heartbeat(), name="dcar-writer-heartbeat"
                    )
                    _submit_current_hold_control(request_app=app)
                else:
                    app.state.writer_heartbeat_at = None
                yield
        finally:
            if heartbeat_task is not None:
                heartbeat_task.cancel()
                try:
                    await heartbeat_task
                except asyncio.CancelledError:
                    pass
            app.state.writer_heartbeat_at = None
            if control_executor is not None:
                control_executor.shutdown(wait=True, cancel_futures=False)
            app.state.current_hold_control_executor = None
            app.state.current_hold_control_future = None
            anchor = getattr(app.state, "sqlite_runtime_anchor", None)
            app.state.sqlite_runtime_anchor = None
            try:
                if anchor is not None:
                    anchor.close()
            finally:
                app.state.writer_lock_held = False
                app.state.writer_lock = {
                    **app.state.writer_lock,
                    "held": False,
                }


router = APIRouter()

READ_ONLY_POST_PATHS = frozenset(
    {
        "/api/v8/accounts/export",
        "/api/v8/accounts/search",
        "/api/v8/contents/search",
        "/api/v8/contents/validate",
        "/api/v8/media-processing/search",
        "/api/inputs/validate",
    }
)


async def privacy_safe_request_log(request: Request, call_next):
    overview_request = request.method == "GET" and request.url.path == "/api/v8/overview"
    if overview_request:
        request.state.overview_started_at = monotonic()
        request.state.overview_timings = {}
    response = await call_next(request)
    if overview_request:
        timings = request.state.overview_timings
        _overview_stage(timings, "total", request.state.overview_started_at)
        # Only bounded stage names and durations; never query strings or IDs.
        response.headers["Server-Timing"] = ", ".join(
            f'{name};dur={duration:.2f}'
            for name, duration in timings.items() if isinstance(duration, (int, float))
        ) + f', cache;desc="{timings.get("cache", "unavailable")}"'
        LOGGER.info("overview_timing %s", json.dumps(timings, sort_keys=True))
    is_read = request.method in {"GET", "HEAD", "OPTIONS"} or (
        request.method == "POST" and request.url.path in READ_ONLY_POST_PATHS
    )
    if not is_read and 200 <= response.status_code < 400:
        cache = getattr(request.app.state, "read_model_cache", None)
        if isinstance(cache, ReadModelCache):
            cache.clear()
    LOGGER.info("%s %s %s", request.method, request.url.path, response.status_code)
    return response


async def read_only_replica_guard(request: Request, call_next):
    config = _request_config(request)
    allowed = request.method in {"GET", "HEAD", "OPTIONS"} or (
        request.method == "POST" and request.url.path in READ_ONLY_POST_PATHS
    )
    if config.read_only and not allowed:
        return JSONResponse(
            status_code=403,
            content={
                "detail": "当前处于只读保护模式：可以查看数据，但暂时不能新增、编辑或刷新。请等写入服务恢复后再试。"
            },
        )
    return await call_next(request)


def create_app(config: Optional[ApiConfig] = None) -> FastAPI:
    application = FastAPI(title="DCar Insight API", version=CURRENT_REPORT_VERSION, lifespan=lifespan)
    application_config = config or ApiConfig.from_env()
    application.state.config = application_config
    # Each app/database pair shares one verified receipt scan per TTL.
    application.state.data_freshness_cache = DataFreshnessCache()
    application.state.read_model_cache = ReadModelCache()
    application.state.current_hold_control_lock = threading.RLock()
    application.state.current_hold_control_future = None
    application.state.current_hold_control_wake_generation = 0
    application.state.current_hold_control_futures = set()
    application.add_middleware(JSONGZipMiddleware, minimum_size=1_000, compresslevel=5)
    application.add_middleware(
        CORSMiddleware,
        allow_origin_regex=r"http://(?:localhost|127\.0\.0\.1):\d{2,5}",
        allow_credentials=False,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type"],
        expose_headers=["Content-Disposition"],
    )
    application.middleware("http")(privacy_safe_request_log)
    application.middleware("http")(read_only_replica_guard)
    application.include_router(router)
    return application


def _scheduler_execution_state(config: ApiConfig, scheduler: Any) -> str:
    if config.read_only:
        return "read_only"
    state = getattr(scheduler, "state", None)
    if state == STATE_RUNNING:
        return "running"
    if state == STATE_PAUSED:
        return "paused"
    return "stopped"


@router.get("/api/v8/health")
def v8_health(request: Request) -> Dict[str, Any]:
    from .paid_drain import dispatch_state
    from .snapshot_contract import descriptor
    config = _request_config(request)
    with connect(config.db_path, read_only=config.read_only) as connection:
        database_state = _database_state(connection)
        media_lifecycle = media_api.lifecycle_status(connection, read_only=config.read_only)
        drain = dispatch_state(connection)
        database_state["sha256"] = getattr(request.app.state, "database_sha256", None)
    data_freshness = _request_data_freshness(request)
    scheduler = getattr(request.app.state, "scheduler", None)
    scheduler_state = _scheduler_execution_state(config, scheduler)
    registered_job_ids = {
        str(job.id) for job in scheduler.get_jobs()
    } if scheduler is not None else set()
    activation = media_lifecycle.get("activation") or {}
    lifecycle_jobs_enabled = bool(
        not config.read_only
        and scheduler_state == "running"
        and activation.get("mode") == "active"
        and media_retention.LIFECYCLE_JOB_IDS <= registered_job_ids
    )
    return {
        "status": "ok",
        "automation": {
            "scheduler_state": scheduler_state,
            "report_from_date": config.daily_capture_reconcile_from.isoformat() if config.daily_capture_reconcile_from else None,
            "paid_dispatch_state": drain.state,
        },
        "mode": "read_only_replica" if config.read_only else "local_v8",
        "read_only": config.read_only,
        "report_version": CURRENT_REPORT_VERSION,
        "database": config.db_path.name,
        "database_path": str(config.db_path.resolve()),
        "runtime_database_identity": getattr(
            request.app.state, "runtime_database_identity", None
        ),
        "writer_lock": getattr(
            request.app.state,
            "writer_lock",
            {
                "path": getattr(request.app.state, "writer_lock_path", None),
                "device": None,
                "inode": None,
                "held": False,
            },
        ),
        "database_state": database_state,
        "data_freshness": data_freshness,
        "paid_dispatch_state": (
            "open"
            if drain.state == "open"
            else "drained"
            if drain.state in {"draining", "sealed"}
            else "invalid"
        ),
        "cutover_state": {
            "state": drain.state,
            "drain_id": drain.drain_id,
            "last_event_id": drain.last_event_id,
            "reason": drain.reason,
        },
        "media_lifecycle": media_lifecycle,
        "snapshot_contract": descriptor(),
        "media_consumers": media_consumer_proofs.runtime_identity(),
        "lifecycle_jobs_enabled": lifecycle_jobs_enabled,
    }


@router.get("/api/v8/livez")
def v8_livez() -> Dict[str, Any]:
    """Process liveness is deliberately O(1) and never touches SQLite."""

    return {"status": "alive"}


@router.post(
    "/api/v8/internal/current-activation-hold/commands", status_code=202
)
def submit_current_activation_hold_command(
    request: Request, payload: CurrentActivationHoldCommandRequest
) -> Dict[str, Any]:
    """Persist an operator command; the single writer executor runs it later."""

    config = _request_config(request)
    if config.read_only:
        raise HTTPException(status_code=403, detail="read_only_replica")
    if not bool(getattr(request.app.state, "writer_lock_held", False)) or getattr(
        request.app.state, "current_hold_control_executor", None
    ) is None:
        raise HTTPException(status_code=503, detail="writer_lock_not_held")
    if payload.parameters is not None and payload.binding is not None:
        raise HTTPException(status_code=422, detail="command_binding_is_ambiguous")
    parameters = payload.parameters if payload.parameters is not None else payload.binding
    if parameters is None:
        raise HTTPException(status_code=422, detail="command_binding_is_required")
    try:
        queued = enqueue_current_activation_hold_command(
            db_path=config.db_path,
            command_id=payload.command_id,
            command=payload.command,
            parameters=parameters,
        )
    except ProfileControlError as exc:
        status_code = 409 if exc.code.endswith("conflict") else 422
        raise HTTPException(
            status_code=status_code, detail={"code": exc.code, "message": str(exc)}
        ) from exc
    except (OSError, sqlite3.Error) as exc:
        raise HTTPException(
            status_code=503,
            detail={
                "code": "durable_command_persist_failed",
                "message": str(exc),
            },
        ) from exc
    command_status = str(queued.get("status") or "")
    if command_status not in {"succeeded", "failed"}:
        try:
            _submit_current_hold_control(request_app=request.app)
        except RuntimeError:
            # The command is already durable.  A concurrent executor shutdown must
            # not turn a safely queued command into an ambiguous client retry; the
            # next writer startup drains it.
            LOGGER.exception("current-hold command queued but executor wakeup failed")
    return {
        "run_id": int(queued["run_id"]),
        "status": (
            command_status if command_status in {"succeeded", "failed"} else "pending"
        ),
    }


@router.get("/api/v8/internal/current-activation-hold/commands/{run_id}")
def get_current_activation_hold_command(
    request: Request, run_id: int
) -> Dict[str, Any]:
    """Pure read of one durable command; this endpoint never claims work."""

    config = _request_config(request)
    try:
        return read_current_activation_hold_command(
            db_path=config.db_path,
            run_id=run_id,
            read_only=True,
            live_wal=bool(getattr(request.app.state, "writer_lock_held", False)),
        )
    except ProfileControlError as exc:
        if exc.code == "current_hold_command_missing":
            raise HTTPException(status_code=404, detail=exc.code) from exc
        raise HTTPException(
            status_code=503, detail={"code": exc.code, "message": str(exc)}
        ) from exc


@router.get("/api/v8/readyz")
def v8_readyz(request: Request):
    """Cheap readiness from DB summaries; never verify raw scan manifests."""

    from .paid_drain import dispatch_state
    from .runtime_receipts import (
        current_activation_readiness,
        latest_runtime_coverage,
    )

    config = _request_config(request)
    timestamp = now_utc()
    with connect(config.db_path, read_only=config.read_only) as connection:
        connection.execute("SELECT 1").fetchone()
        compatibility = schema_compatibility_state(connection)
        if connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' "
            "AND name='acquisition_profile_activations'"
        ).fetchone() is not None:
            from .profile_activations import activation_at

            active = activation_at(connection, timestamp)
            activation_id = (
                int(active["activation_id"]) if active is not None else None
            )
            profile_id = str(active["profile_id"]) if active is not None else None
        else:
            activation_row = connection.execute(
                "SELECT id,completed_at FROM scheduler_runs "
                "WHERE job_id='matrix_pipeline_activation' AND status='succeeded' "
                "ORDER BY id DESC LIMIT 1"
            ).fetchone()
            activation_id = (
                int(activation_row["id"]) if activation_row is not None else None
            )
            profile_id = "matrix_hybrid_v1" if activation_row is not None else None
        coverage = latest_runtime_coverage(connection, at=timestamp)
        drain = dispatch_state(connection)
        current = (
            current_activation_readiness(connection, at=timestamp)
            if activation_id is not None
            else {
                "control_readiness": False,
                "data_readiness": False,
                "reason": "current_activation_receipt_mismatch",
                "receipt": None,
            }
        )
    writer_lock_held = bool(getattr(request.app.state, "writer_lock_held", False))
    writer_runtime = bool(
        config.runtime_access_mode
        in {DatabaseAccessMode.WRITER, DatabaseAccessMode.FORMAL_MUTATION}
        or getattr(request.app.state, "scheduler_requested", False)
        or writer_lock_held
    )
    requires_pipeline_evidence = bool(config.read_only or writer_runtime)
    heartbeat_at = getattr(request.app.state, "writer_heartbeat_at", None)
    heartbeat_age_seconds: float | None = None
    if isinstance(heartbeat_at, str):
        try:
            heartbeat_age_seconds = max(
                0.0,
                (
                    datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                    - datetime.fromisoformat(heartbeat_at.replace("Z", "+00:00"))
                ).total_seconds(),
            )
        except ValueError:
            heartbeat_age_seconds = None
    heartbeat_fresh = bool(
        heartbeat_age_seconds is not None
        and heartbeat_age_seconds <= WRITER_HEARTBEAT_MAX_AGE_SECONDS
    )
    conditions = {
        "database": bool(compatibility["compatible"]),
        # A read-only/local read model may be healthy before an acquisition
        # activation is installed. Only a runtime that requests pipeline
        # evidence treats a closed/invalid paid-dispatch chain as not ready.
        "control_readiness": (
            bool(current["control_readiness"])
            if requires_pipeline_evidence
            else True
        ),
        "writer_lock": (
            writer_lock_held
            if writer_runtime
            else True
        ),
        "writer_heartbeat": (
            heartbeat_fresh
            if writer_runtime
            else True
        ),
        "activation": activation_id is not None if requires_pipeline_evidence else True,
        "profile_day_receipt": (
            bool(current["data_readiness"])
            if requires_pipeline_evidence
            else True
        ),
    }
    ready = all(conditions.values())
    reason: str | None = None
    if not ready:
        if not conditions["database"]:
            reason = "database_incompatible"
        elif not conditions["writer_lock"]:
            reason = "writer_lock_missing"
        elif not conditions["writer_heartbeat"]:
            reason = "writer_heartbeat_stale"
        elif requires_pipeline_evidence:
            reason = str(current.get("reason") or "current_activation_receipt_mismatch")
    payload = {
        "status": "ready" if ready else "not_ready",
        "reason": reason,
        "checked_at": timestamp,
        "conditions": conditions,
        "writer_heartbeat": (
            {
                "observed_at": heartbeat_at,
                "age_seconds": heartbeat_age_seconds,
                "max_age_seconds": WRITER_HEARTBEAT_MAX_AGE_SECONDS,
            }
            if heartbeat_at is not None
            else None
        ),
        "activation_id": activation_id,
        "profile_id": profile_id,
        "profile_day_receipt": current.get("receipt"),
        "closed_business_day_receipt": coverage.get("receipt"),
        "control_readiness": bool(current.get("control_readiness")),
        "data_readiness": bool(current.get("data_readiness")),
        "paid_dispatch_state": drain.state,
        "drain_id": drain.drain_id,
        "loaded_build_id": os.environ.get("DCAR_LOADED_BUILD_ID"),
    }
    return payload if ready else JSONResponse(status_code=503, content=payload)


@router.get("/api/v8/overview")
def get_v8_overview(request: Request) -> Dict[str, Any]:
    timings = getattr(request.state, "overview_timings", None)
    if timings is not None:
        _overview_stage(timings, "queue", request.state.overview_started_at)
    config = _request_config(request)
    started_at = monotonic()
    data_freshness = _request_data_freshness(request)
    _overview_stage(timings, "freshness", started_at)
    freshness_signature = hashlib.sha256(
        json.dumps(
            data_freshness,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    started_at = monotonic()
    try:
        return _request_read_model(
            request,
            ("overview", freshness_signature),
            lambda: v8_overview(
                config.db_path,
                read_only=config.read_only,
                data_freshness=data_freshness,
                timings=timings,
            ),
            timings=timings,
        )
    finally:
        _overview_stage(timings, "read_model", started_at)


@router.get("/api/v8/tasks")
def get_v8_tasks(request: Request) -> Dict[str, Any]:
    items = list_tasks(db_path=_request_config(request).db_path)
    return {"items": items, "total": len(items)}


@router.get("/api/v8/scheduler")
def get_v8_scheduler_status(request: Request) -> Dict[str, Any]:
    config = _request_config(request)
    scheduler = getattr(request.app.state, "scheduler", None)
    scheduler_state = _scheduler_execution_state(config, scheduler)
    registered_jobs = sorted(scheduler.get_jobs(), key=lambda job: str(job.id)) if scheduler is not None else []
    registered_job_ids = [str(job.id) for job in registered_jobs]
    next_runs = [job.next_run_time for job in registered_jobs if isinstance(getattr(job, "next_run_time", None), datetime)]
    with connect(config.db_path, read_only=config.read_only) as connection:
        rows = connection.execute(
            """
            SELECT sr.*,
                   (
                       SELECT COUNT(*) FROM scheduler_run_attempts sra
                       WHERE sra.scheduler_run_id=sr.id
                   ) attempt_count,
                   (
                       SELECT MAX(attempt_number) FROM scheduler_run_attempts sra
                       WHERE sra.scheduler_run_id=sr.id
                   ) latest_attempt_number,
                   (
                       SELECT invocation_source FROM scheduler_run_attempts sra
                       WHERE sra.scheduler_run_id=sr.id
                       ORDER BY attempt_number DESC LIMIT 1
                   ) latest_invocation_source
            FROM scheduler_runs sr
            JOIN (
                SELECT job_id, MAX(id) latest_id
                FROM scheduler_runs WHERE job_id<>? GROUP BY job_id
            ) latest ON latest.job_id=sr.job_id AND latest.latest_id=sr.id
            ORDER BY sr.job_id
            """,
            (ACCOUNT_STATUS_JOB,),
        ).fetchall()
    data_freshness = _request_data_freshness(request)
    return {
        "read_only": config.read_only,
        "requested": bool(getattr(request.app.state, "scheduler_requested", False)),
        "enabled": scheduler_state == "running",
        "state": scheduler_state,
        "paused": scheduler_state == "paused",
        "reconcile_from": config.daily_capture_reconcile_from.isoformat() if config.daily_capture_reconcile_from else None,
        "next_run_at": min(next_runs).isoformat() if next_runs and scheduler_state == "running" else None,
        "registered_job_ids": registered_job_ids,
        "registered_jobs": [
            {"id": str(job.id), "next_run_at": job.next_run_time.isoformat()
             if isinstance(getattr(job, "next_run_time", None), datetime) else None}
            for job in registered_jobs
        ],
        "writer_lock": getattr(
            request.app.state,
            "writer_lock",
            {
                "path": getattr(request.app.state, "writer_lock_path", None),
                "device": None,
                "inode": None,
                "held": False,
            },
        ),
        "report_runtime": {
            "ready": getattr(request.app.state, "report_runtime_ready", None),
            "error": getattr(request.app.state, "report_runtime_error", None),
        },
        "startup_catchup": {
            "mode": "report_only",
            "requested": bool(
                getattr(request.app.state, "startup_catchup_requested", False)
            ),
            "enabled": bool(
                getattr(request.app.state, "startup_catchup_enabled", False)
            ),
            "status": getattr(request.app.state, "catchup_status", "unknown"),
            "error": getattr(request.app.state, "catchup_error", None),
            "results": getattr(request.app.state, "catchup_results", []),
        },
        "pipeline_reconcile": {
            "mode": "current_day_only",
            "enabled": bool(
                scheduler_state == "running"
                and getattr(
                    request.app.state, "pipeline_reconcile_enabled", False
                )
                and "pipeline_reconcile" in registered_job_ids
            ),
            "interval_seconds": DAILY_CAPTURE_RECONCILE_INTERVAL_SECONDS,
            "paid_round_cutoff": "20:00",
        },
        "data_freshness": data_freshness,
        "jobs": [dict(row) for row in rows],
        "scheduler_run_recovery": {
            "interrupted": int(
                getattr(request.app.state, "recovered_scheduler_runs", 0)
            )
        },
        "media_slot_recovery": getattr(
            request.app.state,
            "recovered_media_slots",
            {
                "stale_candidates": 0,
                "recovered": 0,
                "retryable_failed": 0,
                "terminal_failed": 0,
                "cas_conflicts": 0,
                "exhausted_normalized": 0,
            },
        ),
        "fetch_slot_recovery": getattr(
            request.app.state,
            "recovered_fetch_slots",
            {"stale_candidates": 0, "recovered": 0},
        ),
    }


def _run_task_in_background(
    task_id: str, *, db_path: Path, reports_root: Path
) -> None:
    with PIPELINE_REPORT_EXECUTION_LOCK:
        try:
            run_task(task_id, db_path=db_path, reports_root=reports_root)
        except TaskCancelled:
            LOGGER.info("report task cancelled while generating: %s", task_id)
        except Exception:
            # run_task already records the failure on the task; keep the worker alive.
            LOGGER.exception("background report generation failed: %s", task_id)


def _queue_task_run(
    background: BackgroundTasks, task_id: str, config: ApiConfig
) -> None:
    background.add_task(
        _run_task_in_background,
        task_id,
        db_path=config.db_path,
        reports_root=config.reports_root,
    )


def _user_facing_http_error(
    exc: Exception, *, status_code: int, detail: str
) -> HTTPException:
    """Keep technical exception details in logs and return actionable UI copy."""

    LOGGER.warning("request rejected by %s: %s", type(exc).__name__, exc)
    return HTTPException(status_code=status_code, detail=detail)


@router.post("/api/v8/tasks")
def create_v8_task(
    request: Request, payload: TaskCreateRequest, background: BackgroundTasks
) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        with connect(config.db_path) as connection:
            assert_report_runtime_ready(connection)
        task = create_task(
            task_type="custom",
            period_start=payload.period_start,
            period_end=payload.period_end,
            creation_source="manual",
            name=payload.name,
            db_path=config.db_path,
        )
    except ReportTaskError as exc:
        error_text = str(exc)
        if error_text == "manual report period must be closed before creation":
            detail = "结束日期只能选昨天或更早。"
        elif error_text.startswith("invalid ISO date") or error_text == "period_start must not be after period_end":
            detail = "日期范围不正确，请检查开始日期和结束日期。"
        else:
            detail = "报告服务暂时不可用，请稍后重试。"
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail=detail,
        ) from exc
    if str(task["task_status"]) in IMPLICIT_RUN_STATUSES:
        _queue_task_run(background, str(task["id"]), config)
    return task


@router.get("/api/v8/tasks/{task_id}")
def get_v8_task(request: Request, task_id: str) -> Dict[str, Any]:
    try:
        return get_task(task_id, db_path=_request_config(request).db_path)
    except ReportTaskError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=404,
            detail="找不到这个报告任务，请返回列表刷新后重试。",
        ) from exc


@router.post("/api/v8/tasks/{task_id}/corrections", status_code=202)
def correct_v8_task(request: Request, task_id: str, payload: TaskCorrectionRequest,
                    background: BackgroundTasks) -> Dict[str, Any]:
    from .reports import create_correction_task

    config = _request_config(request)
    try:
        with connect(config.db_path) as connection:
            assert_report_runtime_ready(connection)
        task = create_correction_task(task_id, reason=payload.reason.strip(), db_path=config.db_path)
    except ReportTaskError as exc:
        raise _user_facing_http_error(exc, status_code=409,
                                     detail="不能创建更正报告，请核查原报告与更正原因；原报告不会被覆盖。") from exc
    if str(task["task_status"]) in IMPLICIT_RUN_STATUSES:
        _queue_task_run(background, str(task["id"]), config)
    return task


@router.post("/api/v8/tasks/{task_id}/retry")
def retry_v8_task(
    request: Request, task_id: str, background: BackgroundTasks
) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        task = retry_task(task_id, db_path=config.db_path)
    except ReportTaskError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="当前任务状态不支持重新生成，请刷新后重试。",
        ) from exc
    _queue_task_run(background, task_id, config)
    return task


@router.post("/api/v8/tasks/{task_id}/cancel")
def cancel_v8_task(request: Request, task_id: str) -> Dict[str, Any]:
    try:
        return request_task_cancel(task_id, db_path=_request_config(request).db_path)
    except ReportTaskError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="当前任务状态不支持取消，请刷新后重试。",
        ) from exc


@router.post("/api/v8/tasks/{task_id}/resume")
def resume_v8_task(
    request: Request, task_id: str, background: BackgroundTasks
) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        task = resume_task(task_id, db_path=config.db_path)
    except ReportTaskError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="当前任务状态不支持恢复，请刷新后重试。",
        ) from exc
    _queue_task_run(background, task_id, config)
    return task


@router.get("/api/v8/tasks/{task_id}/revisions/{revision}/report")
def get_v8_task_report(request: Request, task_id: str, revision: int) -> Dict[str, Any]:
    with _connect_for_request(request) as connection:
        row = connection.execute(
            "SELECT report_json_path FROM report_revisions WHERE task_id=? AND revision=?",
            (task_id, revision),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="找不到这版报告。")
    path = _safe_project_path(str(row["report_json_path"]))
    if not path.is_file():
        raise HTTPException(
            status_code=410, detail="这份报告的文件丢失了，请重新生成报告。"
        )
    return json.loads(path.read_text(encoding="utf-8"))


@router.get("/api/v8/tasks/{task_id}/revisions/{revision}/files/{file_kind}")
def download_v8_task_file(
    request: Request, task_id: str, revision: int, file_kind: str
) -> FileResponse:
    kinds = (
        ["summary-png", "summary-svg"] if file_kind == "summary-image" else [file_kind]
    )
    placeholders = ",".join("?" for _ in kinds)
    with _connect_for_request(request) as connection:
        rows = connection.execute(
            f"""
            SELECT * FROM report_files
            WHERE task_id=? AND revision=? AND file_kind IN ({placeholders}) AND status='available'
            """,
            (task_id, revision, *kinds),
        ).fetchall()
    by_kind = {str(row["file_kind"]): row for row in rows}
    row = next((by_kind[kind] for kind in kinds if kind in by_kind), None)
    if row is None:
        raise HTTPException(status_code=404, detail="找不到这份报告文件。")
    path = _safe_project_path(str(row["local_path"]))
    if not path.is_file():
        raise HTTPException(
            status_code=410, detail="这份报告的文件丢失了，请重新生成报告。"
        )
    media_types = {
        "report-json": "application/json",
        "report-markdown": "text/markdown",
        "content-csv": "text/csv",
        "channel-csv": "text/csv",
        "summary-svg": "image/svg+xml",
        "summary-png": "image/png",
    }
    return FileResponse(
        path,
        media_type=media_types.get(str(row["file_kind"]), "application/octet-stream"),
        filename=path.name,
    )


def _verified_report_file(row: Mapping[str, Any]) -> tuple[Path, bytes]:
    path = _safe_project_path(str(row["local_path"]))
    if not path.is_file():
        raise HTTPException(
            status_code=410, detail="这份报告的文件丢失了，请重新生成报告。"
        )
    try:
        payload = path.read_bytes()
    except OSError as exc:
        raise HTTPException(
            status_code=410, detail="报告文件无法读取，请重新生成报告。"
        ) from exc
    expected_size = int(row["byte_size"])
    expected_sha256 = str(row["sha256"])
    if len(payload) != expected_size or hashlib.sha256(payload).hexdigest() != expected_sha256:
        raise HTTPException(
            status_code=409, detail="报告文件可能已损坏，请重新生成报告。"
        )
    return path, payload


def _report_export_context(
    request: Request,
    *,
    task_id: str,
    taxonomy_version: str,
    content_csv: bytes,
) -> tuple[dict[str, dict[str, str]], dict[str, str]]:
    """Read-only compatibility projection for fields absent from old revisions."""

    try:
        source_rows = list(
            csv.DictReader(io.StringIO(content_csv.decode("utf-8-sig"), newline=""))
        )
    except (UnicodeDecodeError, csv.Error) as exc:
        raise HTTPException(
            status_code=409,
            detail="这份历史报告缺少下载所需信息，请重新生成一份新报告。",
        ) from exc
    with _connect_for_request(request) as connection:
        current_rows = connection.execute(
            """
            SELECT c.id,c.link_id,c.platform,c.platform_content_id,
                   c.canonical_url,c.content_type
            FROM task_contents tc
            JOIN content_items c ON c.id=tc.content_id
            WHERE tc.task_id=? AND tc.inclusion_status='included'
            ORDER BY c.id
            """,
            (task_id,),
        ).fetchall()
        point_rows = connection.execute(
            """
            SELECT sp.code,sp.label
            FROM taxonomy_versions tv
            JOIN selling_points sp ON sp.taxonomy_id=tv.id
            WHERE tv.version=?
            ORDER BY sp.code
            """,
            (taxonomy_version,),
        ).fetchall()
    current_by_id = {str(row["id"]): row for row in current_rows}
    enrichment: dict[str, dict[str, str]] = {}
    required_codes: set[str] = set()
    for source in source_rows:
        internal_content_id = str(source.get("content_id") or "").strip()
        platform = str(source.get("platform") or "").strip()
        canonical_url = str(source.get("canonical_url") or "").strip()
        platform_content_id = str(source.get("platform_content_id") or "").strip()
        content_type = str(source.get("content_type") or "").strip()
        current = current_by_id.get(internal_content_id)
        needs_current = not platform_content_id or not content_type
        if needs_current and current is None:
            raise HTTPException(
                status_code=409,
                detail="这份历史报告缺少下载所需信息，请重新生成一份新报告。",
            )
        if needs_current and current is not None:
            for key, frozen_value in (
                ("link_id", source.get("link_id")),
                ("platform", source.get("platform")),
                ("canonical_url", source.get("canonical_url")),
            ):
                if str(current[key] or "") != str(frozen_value or ""):
                    raise HTTPException(
                        status_code=409,
                        detail="这份历史报告缺少下载所需信息，请重新生成一份新报告。",
                    )
            platform_content_id = platform_content_id or str(
                current["platform_content_id"] or ""
            )
            content_type = content_type or str(current["content_type"] or "")
        url_content_id = platform_content_id_from_url(platform, canonical_url)
        if not url_content_id or (
            platform_content_id and platform_content_id != url_content_id
        ):
            raise HTTPException(
                status_code=409,
                detail="这份历史报告缺少下载所需信息，请重新生成一份新报告。",
            )
        platform_content_id = platform_content_id or url_content_id
        if not content_type:
            raise HTTPException(
                status_code=409,
                detail="这份历史报告缺少下载所需信息，请重新生成一份新报告。",
            )
        enrichment[internal_content_id] = {
            "platform_content_id": platform_content_id,
            "content_type": content_type,
        }
        code = str(source.get("primary_selling_point_code") or "").strip()
        label = str(source.get("primary_selling_point_label") or "").strip()
        if code and not label:
            required_codes.add(code)
    selling_point_labels = {
        str(row["code"]): str(row["label"]) for row in point_rows
    }
    missing_codes = sorted(required_codes - set(selling_point_labels))
    if missing_codes:
        raise HTTPException(
            status_code=409,
            detail="这份历史报告缺少下载所需信息，请重新生成一份新报告。",
        )
    return enrichment, selling_point_labels


def _report_download_image(
    by_kind: Mapping[str, Mapping[str, Any]], *, task_id: str, revision: int
) -> tuple[str, bytes]:
    """Derive only the requested image, without touching revision CSV files."""

    image_extension: str
    image_bytes: bytes
    derived_svg: Optional[bytes] = None
    if report_row := by_kind.get("report-json"):
        _, report_json = _verified_report_file(report_row)
        try:
            frozen_report = json.loads(report_json.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            LOGGER.exception(
                "report image derivation failed: task=%s revision=%s",
                task_id,
                revision,
            )
            raise HTTPException(
                status_code=500, detail="报告图片生成失败，请稍后重试。"
            ) from exc
        try:
            derived_svg = render_summary_svg(frozen_report).encode("utf-8")
        except ValueError:
            # v8.0/v8.1 predate the registered contract files needed by the
            # current template. Their archived SVG remains the safe fallback.
            LOGGER.warning(
                "current image template unsupported for historical report: "
                "task=%s revision=%s report_version=%s",
                task_id,
                revision,
                frozen_report.get("report_version"),
            )

    if derived_svg is not None:
        with tempfile.TemporaryDirectory(prefix="dcar-report-download-") as directory:
            svg_path = Path(directory) / "core_summary.svg"
            svg_path.write_bytes(derived_svg)
            rendered = Path(directory) / "core_summary.png"
            if render_summary_png(svg_path, rendered):
                image_extension = "png"
                image_bytes = rendered.read_bytes()
            else:
                image_extension = "svg"
                image_bytes = derived_svg
    elif svg_row := by_kind.get("summary-svg"):
        svg_path, svg_bytes = _verified_report_file(svg_row)
        with tempfile.TemporaryDirectory(prefix="dcar-report-download-") as directory:
            rendered = Path(directory) / "core_summary.png"
            if render_summary_png(svg_path, rendered):
                image_extension = "png"
                image_bytes = rendered.read_bytes()
            else:
                image_extension = "svg"
                image_bytes = svg_bytes
    elif png_row := by_kind.get("summary-png"):
        _, image_bytes = _verified_report_file(png_row)
        image_extension = "png"
    else:
        raise HTTPException(
            status_code=404, detail="这份报告的图片丢失了，请重新生成报告。"
        )
    return image_extension, image_bytes


def _report_download_response(
    payload: bytes, *, filename: str, media_type: str, extension: str
) -> Response:
    encoded_filename = quote(filename, safe="")
    return Response(
        content=payload,
        media_type=media_type,
        headers={
            "Content-Disposition": (
                f'attachment; filename="report.{extension}"; filename*=UTF-8\'\'{encoded_filename}'
            ),
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.get("/api/v8/tasks/{task_id}/revisions/{revision}/download")
def download_v8_task_report(
    request: Request,
    task_id: str,
    revision: int,
    format: Literal["zip", "image", "xlsx"] = "zip",
) -> Response:
    """Download one immutable revision artifact, or its legacy ZIP bundle."""

    with _connect_for_request(request) as connection:
        task = connection.execute(
            """
            SELECT t.id,t.name,t.period_start,t.period_end,t.task_status,t.created_at,
                   rr.created_at revision_created_at,rr.taxonomy_version
            FROM report_revisions rr
            JOIN report_tasks t ON t.id=rr.task_id
            WHERE rr.task_id=? AND rr.revision=?
            """,
            (task_id, revision),
        ).fetchone()
        files = connection.execute(
            """
            SELECT file_kind,local_path,sha256,byte_size
            FROM report_files
            WHERE task_id=? AND revision=? AND status='available'
              AND file_kind IN (
                  'report-json','summary-svg','summary-png','content-csv','channel-csv'
              )
            """,
            (task_id, revision),
        ).fetchall()
    if task is None:
        raise HTTPException(status_code=404, detail="找不到这版报告。")

    by_kind = {str(row["file_kind"]): row for row in files}
    if format == "image":
        image_extension, image_bytes = _report_download_image(
            by_kind, task_id=task_id, revision=revision
        )
        return _report_download_response(
            image_bytes,
            filename=report_file_filename(
                task_name=str(task["name"]),
                task_id=task_id,
                revision=revision,
                extension=image_extension,
            ),
            media_type="image/png" if image_extension == "png" else "image/svg+xml",
            extension=image_extension,
        )

    content_row = by_kind.get("content-csv")
    if content_row is None:
        raise HTTPException(
            status_code=404, detail="这份报告的内容明细丢失了，请重新生成报告。"
        )
    _, content_csv = _verified_report_file(content_row)

    channel_csv = None
    if channel_row := by_kind.get("channel-csv"):
        _, channel_csv = _verified_report_file(channel_row)

    if format == "zip":
        image_extension, image_bytes = _report_download_image(
            by_kind, task_id=task_id, revision=revision
        )

    task_value = dict(task)
    content_enrichment, selling_point_labels = _report_export_context(
        request,
        task_id=task_id,
        taxonomy_version=str(task["taxonomy_version"]),
        content_csv=content_csv,
    )
    try:
        workbook = build_report_detail_workbook(
            task=task_value,
            revision=revision,
            content_csv=content_csv,
            channel_csv=channel_csv,
            content_enrichment=content_enrichment,
            selling_point_labels=selling_point_labels,
        )
        if format == "zip":
            bundle = build_report_download_bundle(
                image_extension=image_extension,
                image_bytes=image_bytes,
                workbook_bytes=workbook,
            )
    except (UnicodeDecodeError, csv.Error, ValueError) as exc:
        LOGGER.exception(
            "report bundle generation failed: task=%s revision=%s", task_id, revision
        )
        raise HTTPException(
            status_code=500, detail="报告打包失败，请稍后重试。"
        ) from exc

    if format == "xlsx":
        return _report_download_response(
            workbook,
            filename=report_file_filename(
                task_name=str(task["name"]),
                task_id=task_id,
                revision=revision,
                extension="xlsx",
            ),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            extension="xlsx",
        )
    return _report_download_response(
        bundle,
        filename=report_bundle_filename(
            task_name=str(task["name"]),
            task_id=task_id,
        ),
        media_type="application/zip",
        extension="zip",
    )



def _roster_http_error(error: RosterError) -> HTTPException:
    messages = {
        "missing_stable_key": "官方导出缺少矩阵账号编号或主页链接，请重新导出完整名册。",
        "unrecognized_export": "未识别到完整名册的必要字段，统计列表不能用作账号名册。",
        "incomplete_roster": "文件实取数量与官方声明总量不一致，请上传完整名册。",
               "incomplete_scope": "必须提供当前组织、全部平台和全部已添加账号的完整范围证明。",
        "identity_conflict": "矩阵账号编号、平台编号或主页归属冲突，本次未更新名单。",
        "identity_unresolved": "首次初始化仍有身份未对齐，不能重复建档或按手机号合并。",
        "rounded_numeric_id": "导出含可能失真的数字长编号，请使用文本格式的原始编号。",
        "stale_source": "该导出早于已接受名册，请重新从矩阵通导出。",
        "scope_changed": "组织或全量范围与当前名册不同，本次未更新名单。",
        "export_too_large": "导出文件为空或超过大小限制，请检查后重试。",
        "manual_export_required": "全量名册接口尚未验证，请上传新的矩阵通官方完整导出。",
        "system_member_exists": "该平台 UID 已在系统名单中，请直接修改运营信息。",
        "system_member_not_found": "该账号不在当前系统名单中。",
        "system_roster_already_exists": "系统名单已经初始化，无需重复从矩阵通复制。",
        "system_roster_reason_required": "系统名单变更必须填写操作原因。",
    }
    return HTTPException(
        status_code=409,
        detail=messages.get(error.code, "完整名册未通过校验，请检查导出字段、来源证明和独立导出时间。"),
        headers={"X-DCAR-Roster-Error": error.code},
    )


def _schedule_writer_roster_activation(
    request: Request,
    connection: sqlite3.Connection,
    result: Mapping[str, Any],
    *,
    reason: str,
) -> dict[str, Any]:
    """Bind an accepted same-family roster while the owning writer lock is held."""

    value = dict(result)
    if value.get("status") != "accepted" or not bool(
        getattr(request.app.state, "writer_lock_held", False)
    ):
        return value
    try:
        scheduled = schedule_accepted_roster_activation_in_transaction(
            connection,
            roster_snapshot_id=int(value["snapshot_id"]),
            actor="api-operator",
            reason=reason,
        )
    except ProfileControlError as error:
        raise RosterError(error.code, str(error)) from error
    if not scheduled["scheduled"]:
        return value
    activation = scheduled["activation"]
    return {
        **value,
        "activation_status": "scheduled",
        "scheduled_activation_id": int(activation["activation_id"]),
        "scheduled_effective_at": str(activation["effective_at"]),
    }


def _roster_source_root(config: ApiConfig) -> Path:
    """Keep new roster evidence in this runtime's snapshot-transferable cache."""

    return (
        config.project_root.expanduser().resolve()
        / "data/cache/v8/raw_responses/roster_sources"
    )


@router.get("/api/v8/account-roster")
def get_v8_account_roster(request: Request) -> Dict[str, Any]:
    with _connect_for_request(request) as connection:
        return runtime_account_summary(connection)


@router.get("/api/v8/account-roster/candidates/{candidate_id}")
def get_v8_roster_diff(request: Request, candidate_id: int) -> Dict[str, Any]:
    try:
        with _connect_for_request(request) as connection:
            return candidate_diff(connection, candidate_id)
    except RosterError as error:
        raise _roster_http_error(error) from error


@router.post("/api/v8/account-roster/sync")
def sync_v8_account_roster(request: Request) -> Dict[str, Any]:
    # There is no verified full-roster endpoint yet. Do not reuse account/list,
    # discover authors, or silently accept a cached candidate as a fresh sync.
    with _connect_for_request(request) as connection:
        runtime = runtime_account_summary(connection)
        if runtime.get("active_profile_id") == TIKHUB_PROFILE:
            return {
                "status": "managed_locally",
                "message": "当前使用系统名单；成员变更会封存新快照并在下一次名单激活边界生效。",
                "roster": runtime,
            }
        summary = account_summary(connection)
    return {
        "status": "manual_export_required",
        "message": "全量名册接口尚未验证。请上传新的矩阵通官方完整导出；当前名单未改变。",
        "roster": summary,
    }


@router.post("/api/v8/account-roster/system/bootstrap")
def bootstrap_v8_system_roster(
    request: Request, payload: SystemRosterBootstrapRequest
) -> Dict[str, Any]:
    """Prepare the first inactive system roster without changing the live profile."""

    config = _request_config(request)
    try:
        with _connect_for_request(request) as connection, transaction(connection):
            result = bootstrap_system_roster_from_matrix(
                connection,
                raw_root=_roster_source_root(config),
                actor="api-operator",
                reason=payload.reason,
            )
            result = _schedule_writer_roster_activation(
                request,
                connection,
                result,
                reason="activate accepted system roster",
            )
        return {
            **result,
            "message": "系统名单已从 UID 完整的矩阵通当前名单封存；尚未切换采集模式。",
        }
    except RosterError as error:
        raise _roster_http_error(error) from error


@router.post("/api/v8/account-roster/import")
def import_v8_account_roster(request: Request, payload: RosterUploadRequest) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        source = base64.b64decode(payload.content_base64, validate=True)
    except (ValueError, binascii.Error) as error:
        raise HTTPException(status_code=422, detail="导出文件编码无效。") from error
    try:
        with _connect_for_request(request) as connection, transaction(connection):
            first = current_snapshot(connection) is None
            members = decode_official_export(source, source_name=payload.source_name, allow_empty=not first)
            candidate = prepare_candidate(
                connection,
                {
                    "source_type": "bootstrap_export" if first else "manual_export",
                    "require_existing_identities": first,
                    "scope": {
                        "organization": payload.organization,
                        "coverage": "full", "account_scope": "all_added_accounts",
                        "platforms": ["douyin", "xiaohongshu", "wechat_channels", "kuaishou"],
                    },
                    "source_captured_at": payload.source_exported_at,
                    "source_evidence": {
                        "kind": "official_export", "evidence_kind": "operator_declaration",
                        "export_record_id": payload.source_instance_id,
                        "exported_at": payload.source_exported_at,
                        "scope_evidence": payload.evidence_note,
                        "source_sha256": hashlib.sha256(source).hexdigest(),
                        "source_name": payload.source_name,
                    },
                    "members": members, "declared_count": payload.declared_count,
                    "pagination": {
                        "expected_pages": 1, "pages": [1], "terminal": True,
                        "declared_totals": [payload.declared_count],
                    },
                },
                source_bytes=source,
                raw_root=_roster_source_root(config),
            )
            accepted = accept_candidate(connection, int(candidate["candidate_id"]))
            accepted = _schedule_writer_roster_activation(
                request,
                connection,
                accepted,
                reason="activate accepted Matrix roster",
            )
            summary = account_summary(connection)
        return {
            **accepted,
            "message": "完整名册已接受并同步。"
            if accepted["status"] == "accepted"
            else "检测到移除，暂保留原名单。请至少十分钟后重新导出独立的完整名册确认。",
            "roster": summary,
        }
    except RosterError as error:
        raise _roster_http_error(error) from error


@router.post("/api/v8/accounts/search")
def search_v8_accounts(
    request: Request, payload: AccountSearchRequest
) -> Dict[str, Any]:
    config = _request_config(request)
    return _account_search(
        payload,
        db_path=config.db_path,
        read_only=config.read_only,
    )


@router.post("/api/v8/accounts")
def create_v8_account(
    request: Request, payload: Dict[str, Any]
) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        with _connect_for_request(request) as connection, transaction(connection):
            runtime = runtime_account_summary(connection)
            if runtime.get("active_profile_id") != TIKHUB_PROFILE:
                raise HTTPException(
                    status_code=410,
                    detail="当前账号成员由矩阵通管理，请在矩阵通添加后上传官方完整名册。",
                )
            try:
                member = SystemAccountMemberRequest.model_validate(payload).model_dump()
            except ValueError as error:
                raise HTTPException(
                    status_code=422, detail="系统账号的平台、UID 或主页格式无效。"
                ) from error
            if any(
                row["platform"] == member["platform"]
                and row["uid"] == member["uid"]
                for row in current_system_members(connection)
            ):
                raise RosterError(
                    "system_member_exists", "System roster member already exists"
                )
            result = upsert_system_members(
                connection,
                [member],
                raw_root=_roster_source_root(config),
                actor="api-operator",
                reason="add managed account member",
            )
            result = _schedule_writer_roster_activation(
                request,
                connection,
                result,
                reason="activate added managed account",
            )
            identity = connection.execute(
                "SELECT account_id FROM account_platform_identities WHERE platform=? AND uid=?",
                (member["platform"], member["uid"]),
            ).fetchone()
            if identity is None:
                raise RosterError(
                    "identity_unresolved", "Accepted system member has no local identity"
                )
        return {
            **result,
            "account_id": int(identity["account_id"]),
            "message": "账号已加入下一版系统名单，将在下一次名单激活边界生效。",
        }
    except RosterError as error:
        raise _roster_http_error(error) from error


@router.patch("/api/v8/accounts/{account_id}")
def patch_v8_account(
    request: Request, account_id: int, payload: AccountMutationRequest
) -> Dict[str, Any]:
    try:
        values = payload.model_dump(exclude_unset=True)
        if "status_request_id" in values and "account_status" not in values:
            raise HTTPException(status_code=422, detail="账号状态请求编号需要同时提交账号状态。")
        if "account_status" in values:
            if values["account_status"] is None:
                raise HTTPException(status_code=422, detail="请选择日更、周更或暂停。")
            if "enabled" in values:
                raise HTTPException(status_code=422, detail="账号状态与采集开关不能同时提交。")
            config = _request_config(request)
            with _connect_for_request(request) as connection, transaction(connection):
                runtime = runtime_account_summary(connection)
                if runtime.get("active_profile_id") != TIKHUB_PROFILE:
                    raise HTTPException(status_code=409, detail="账号状态仅支持系统托管名单模式。")
                activation_id = runtime.get("activation_id")
                result = update_account_operating_status_in_transaction(
                    connection,
                    account_id,
                    values,
                    raw_root=_roster_source_root(config),
                    actor="api-operator",
                    reason="manual account status update",
                    activation_id=int(activation_id) if activation_id is not None else None,
                    schedule_activation=lambda conn, roster_result: _schedule_writer_roster_activation(
                        request, conn, roster_result, reason="activate account status roster change"
                    ),
                )
            return {
                **result,
                "message": (
                    "账号已暂停采集，并退出当前统计；名单快照变更将在下一激活边界生效。"
                    if values["account_status"] == "paused"
                    else "账号更新频率已保存；新增名单成员将在下一激活边界生效。"
                    if result.get("roster_change")
                    else "账号更新频率已保存，采集规则保持不变。"
                ),
            }
        with _connect_for_request(request) as connection:
            activation_id = runtime_account_summary(connection).get("activation_id")
        return update_account(
            account_id,
            values,
            db_path=_request_config(request).db_path,
            actor="api-operator",
            reason="account operations update",
            activation_id=(int(activation_id) if activation_id is not None else None),
        )
    except AccountOperatingStatusError as exc:
        raise HTTPException(
            status_code=409,
            detail=str(exc),
        ) from exc
    except RosterError as exc:
        raise _roster_http_error(exc) from exc
    except OperationError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="账号保存失败，请检查手机号和填写内容后重试。",
        ) from exc


@router.post("/api/v8/accounts/import")
def import_v8_accounts(request: Request, payload: BulkImportRequest) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        with _connect_for_request(request) as connection, transaction(connection):
            runtime = runtime_account_summary(connection)
            if runtime.get("active_profile_id") != TIKHUB_PROFILE:
                raise HTTPException(
                    status_code=410,
                    detail="当前不在系统名单模式；请上传矩阵通官方完整名册。",
                )
            result = upsert_system_members(
                connection,
                payload.rows,
                raw_root=_roster_source_root(config),
                actor="api-operator",
                reason=f"managed account import: {payload.source_name}",
            )
            result = _schedule_writer_roster_activation(
                request,
                connection,
                result,
                reason="activate imported managed accounts",
            )
        return {
            **result,
            "message": "有效账号已合并到下一版系统名单；坏行已逐行拒绝。",
        }
    except RosterError as error:
        raise _roster_http_error(error) from error


@router.delete("/api/v8/accounts/{account_id}")
def remove_v8_account(request: Request, account_id: int) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        with _connect_for_request(request) as connection, transaction(connection):
            runtime = runtime_account_summary(connection)
            if runtime.get("active_profile_id") != TIKHUB_PROFILE:
                raise HTTPException(
                    status_code=410,
                    detail="当前账号成员由矩阵通管理，不能在本地移出名单。",
                )
            result = remove_system_member(
                connection,
                account_id,
                raw_root=_roster_source_root(config),
                actor="api-operator",
                reason="remove managed account member",
            )
            result = _schedule_writer_roster_activation(
                request,
                connection,
                result,
                reason="activate managed account removal",
            )
        return {
            **result,
            "message": "账号已移出下一版系统名单；身份和历史数据继续保留。",
        }
    except RosterError as error:
        raise _roster_http_error(error) from error


@router.post("/api/v8/accounts/export")
def export_v8_accounts(request: Request, payload: AccountExportRequest) -> Response:
    workbook = export_accounts_xlsx(
        scope=payload.scope,
        read_only=_request_config(request).read_only,
        douyin_authorization_targets=(
            None
            if payload.douyin_authorization_targets is None
            else [
                (target.account_id, target.platform_uid, target.state)
                for target in payload.douyin_authorization_targets
            ]
        ),
        db_path=_request_config(request).db_path,
    )
    filename = accounts_workbook_filename(datetime.now(SHANGHAI))
    encoded_filename = quote(filename, safe="")
    return Response(
        content=workbook,
        media_type=(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                f'attachment; filename="dcar-accounts.xlsx"; '
                f"filename*=UTF-8''{encoded_filename}"
            ),
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.post("/api/v8/contents/search")
def search_v8_contents(
    request: Request, payload: ContentSearchRequest
) -> Dict[str, Any]:
    config = _request_config(request)
    return _content_search(
        payload,
        db_path=config.db_path,
        read_only=config.read_only,
    )


@router.post("/api/v8/contents/validate")
def validate_v8_contents(payload: BulkImportRequest) -> Dict[str, Any]:
    items: List[Dict[str, Any]] = []
    valid = 0
    for index, row in enumerate(payload.rows, start=1):
        try:
            identity = content_identity(
                str(row.get("platform") or ""),
                str(row.get("canonical_url") or row.get("url") or ""),
                row.get("platform_content_id"),
            )
            items.append({"row": index, "status": "valid", **identity})
            valid += 1
        except OperationError as exc:
            items.append({"row": index, "status": "rejected", "reason": str(exc)})
    return {
        "total": len(payload.rows),
        "valid": valid,
        "rejected": len(payload.rows) - valid,
        "items": items,
    }


@router.post("/api/v8/contents")
def create_v8_content(
    request: Request, payload: ContentMutationRequest
) -> Dict[str, Any]:
    try:
        return upsert_content(
            payload.model_dump(), db_path=_request_config(request).db_path
        )
    except OperationError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="内容保存失败，请检查链接和填写内容后重试。",
        ) from exc


@router.patch("/api/v8/contents/{content_id}")
def patch_v8_content(
    request: Request, content_id: int, payload: ContentPatchRequest
) -> Dict[str, Any]:
    updates = payload.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=422, detail="请至少修改一项内容。")
    try:
        return update_content(
            content_id,
            updates,
            db_path=_request_config(request).db_path,
        )
    except OperationError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="内容保存失败，请检查链接和填写内容后重试。",
        ) from exc


@router.post("/api/v8/contents/import")
def import_v8_contents(request: Request, payload: BulkImportRequest) -> Dict[str, Any]:
    return import_contents(
        payload.rows,
        source_name=payload.source_name,
        db_path=_request_config(request).db_path,
    )


@router.post("/api/v8/contents/{content_id}/update-data")
def update_v8_content_data(request: Request, content_id: int) -> Any:
    db_path = _request_config(request).db_path
    try:
        result = update_content_data(content_id, db_path=db_path)
    except LifecycleError as exc:
        return media_api.error_response(exc)
    except (BudgetBlocked, SlotUnavailable, CaptureError, RosterError) as exc:
        raise _user_facing_http_error(exc, status_code=409,
                                     detail="当前名单、采集周期或预算不允许更新；系统不会绕过固定取数规则。") from exc
    except ProviderConfigurationError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="在线更新服务尚未配置，请联系管理员。",
        ) from exc
    try:
        # 数据更新后即时补算 车型/人群/场景 标签，让内容列表立刻反映最新证据
        associate_single_content(content_id, db_path=db_path)
    except (SpuAudienceError, sqlite3.Error):
        LOGGER.exception("内容 %s 更新后补算三标签失败（不影响数据更新结果）", content_id)
    return result


@router.get("/api/v8/contents/{content_id}/evidence")
def get_v8_content_evidence(request: Request, content_id: int) -> Any:
    config = _request_config(request)
    try:
        return _content_evidence(content_id, db_path=config.db_path, read_only=config.read_only)
    except (LifecycleError, MediaProcessingError) as error:
        LOGGER.warning("media evidence unavailable content=%s code=%s", content_id, getattr(error, "error_code", type(error).__name__))
        return media_api.error_response(error)


@router.api_route("/api/v8/contents/{content_id}/evidence/files/{artifact_id}/{index}", methods=["GET", "HEAD"])
def get_v8_content_evidence_file(
    request: Request, content_id: int, artifact_id: int, index: int
) -> Response:
    config = _request_config(request)
    with _connect_for_request(request) as connection:
        try:
            managed_response = media_api.original_response(connection, content_id, artifact_id, index,
                                                         db_path=config.db_path, read_only=config.read_only)
        except (LifecycleError, MediaProcessingError) as error:
            return media_api.error_response(error)
        if managed_response is not None:
            return managed_response
        row = connection.execute(
            """
            SELECT * FROM evidence_artifacts
            WHERE id=? AND content_id=? AND artifact_type IN ('media','media_manifest')
              AND status='available'
            """,
            (artifact_id, content_id),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="还没有可查看的图片或视频。")
    paths = _artifact_media_paths(row, read_only=config.read_only)
    if not paths:
        if config.read_only:
            raise HTTPException(
                status_code=410,
                detail="线上版本没有包含这张图片或视频，当前无法查看。请回到本地重新处理并发布。",
            )
        raise HTTPException(
            status_code=404, detail="本地图片或视频文件丢失，请重新处理媒体。"
        )
    if index < 0 or index >= len(paths):
        raise HTTPException(
            status_code=404, detail="本地图片或视频文件丢失，请重新处理媒体。"
        )
    path = paths[index]
    if path is None:
        raise HTTPException(status_code=404, detail="该编号的原件缺失，其他图片不会改用这个编号。")
    return FileResponse(path, media_type=media_api.media_content_type(path))


@router.get("/api/v8/contents/{content_id}/evidence/previews/{artifact_id}/{index}")
def get_v8_content_preview(request: Request, content_id: int, artifact_id: int, index: int) -> Response:
    try:
        with _connect_for_request(request) as connection:
            return media_api.preview_response(connection, content_id, artifact_id, index)
    except (LifecycleError, MediaProcessingError, OSError, ValueError) as error:
        return media_api.error_response(error)


@router.post("/api/v8/contents/{content_id}/media/restore", status_code=202)
def restore_v8_content_media(request: Request, content_id: int, payload: MediaRestoreRequest) -> Response:
    from .media_retention import request_restore

    config = _request_config(request)
    if config.read_only:
        raise HTTPException(status_code=403, detail="只读副本不能恢复原件，请在本地写入服务操作。")
    try:
        result = request_restore(content_id, payload.bundle_id, payload.purpose, db_path=config.db_path)
        return JSONResponse({**result, "bundle_id": payload.bundle_id, "provider_cost": 0.0}, status_code=202)
    except (LifecycleError, MediaProcessingError, OSError, ValueError) as error:
        return media_api.error_response(error)


@router.post("/api/v8/contents/{content_id}/media/retry")
def retry_v8_content_media(
    request: Request, content_id: int, payload: MediaRetryRequest
) -> Any:
    try:
        return retry_content_media(
            content_id,
            allow_paid_refresh=payload.allow_paid_refresh,
            db_path=_request_config(request).db_path,
        )
    except LifecycleError as exc:
        return media_api.error_response(exc)
    except (
        ProviderConfigurationError,
        MediaProcessingError,
        CaptureError,
        SlotUnavailable,
        BudgetBlocked,
    ) as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="媒体重新处理失败，请稍后重试；如果一直失败，请联系管理员。",
        ) from exc


@router.get("/api/v8/media/lifecycle")
def get_v8_media_lifecycle(request: Request) -> Any:
    config = _request_config(request)
    try:
        with _connect_for_request(request) as connection:
            return media_api.lifecycle_status(connection, read_only=config.read_only)
    except (LifecycleError, MediaProcessingError, OSError, ValueError) as error:
        return media_api.error_response(error)


@router.post("/api/v8/media-processing/search")
def search_v8_media_processing(
    request: Request, payload: MediaProcessingSearchRequest
) -> Dict[str, Any]:
    where: List[str] = []
    parameters: List[Any] = []
    if payload.status:
        where.append("m.status=?")
        parameters.append(payload.status)
    if payload.processor_type:
        where.append("m.processor_type=?")
        parameters.append(payload.processor_type)
    if payload.content_id:
        where.append("m.content_id=?")
        parameters.append(payload.content_id)
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""
    offset = (payload.page - 1) * payload.page_size
    with _connect_for_request(request) as connection:
        total = int(
            connection.execute(
                f"SELECT COUNT(*) FROM media_processing_slots m {where_sql}", parameters
            ).fetchone()[0]
        )
        status_rows = connection.execute(
            f"""
            SELECT m.status, COUNT(*) count
            FROM media_processing_slots m
            {where_sql}
            GROUP BY m.status
            """,
            parameters,
        ).fetchall()
        rows = connection.execute(
            f"""
            SELECT m.id,m.content_id,c.link_id,c.platform,m.processor_type,
                   m.processor_version,m.status,m.attempt_count,m.error_message,m.updated_at
            FROM media_processing_slots m
            JOIN content_items c ON c.id=m.content_id
            {where_sql}
            ORDER BY m.updated_at DESC,m.id DESC LIMIT ? OFFSET ?
            """,
            [*parameters, payload.page_size, offset],
        ).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["error_message"] = _friendly_media_processing_error(item.get("error_message"))
        items.append(item)
    return {
        "items": items,
        "total": total,
        "slot_status_counts": {
            status: next(
                (int(row["count"]) for row in status_rows if row["status"] == status),
                0,
            )
            for status in (
                "pending",
                "running",
                "succeeded",
                "retryable_failed",
                "terminal_failed",
            )
        },
        "page": payload.page,
        "page_size": payload.page_size,
    }


@router.get("/api/v8/contents/export")
def export_v8_contents(request: Request) -> Response:
    return Response(
        export_contents_csv(db_path=_request_config(request).db_path),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="dcar-contents.csv"'},
    )


@router.get("/api/v8/selling-points")
def get_v8_selling_points(request: Request) -> Dict[str, Any]:
    try:
        config = _request_config(request)
        return _request_read_model(
            request,
            ("selling-points",),
            lambda: _selling_point_list(
                db_path=config.db_path,
                read_only=config.read_only,
            ),
        )
    except TaxonomyError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="卖点标准暂时无法读取，请联系管理员。",
        ) from exc


@router.post("/api/v8/selling-points/draft")
def create_v8_selling_point_draft(request: Request) -> Dict[str, Any]:
    try:
        return ensure_draft(db_path=_request_config(request).db_path)
    except TaxonomyError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="无法进入草稿编辑，请刷新页面后重试。",
        ) from exc


@router.get("/api/v8/selling-points/draft")
def get_v8_selling_point_draft(request: Request) -> Dict[str, Any]:
    try:
        return list_points(status="draft", db_path=_request_config(request).db_path)
    except TaxonomyError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="卖点草稿暂时无法读取，请刷新页面后重试。",
        ) from exc


@router.post("/api/v8/selling-points/items")
def create_v8_selling_point(
    request: Request, payload: SellingPointMutationRequest
) -> Dict[str, Any]:
    if payload.code is None:
        raise HTTPException(status_code=422, detail="请填写卖点编号。")
    try:
        return create_point(
            payload.model_dump(), db_path=_request_config(request).db_path
        )
    except TaxonomyValidationError as exc:
        raise _user_facing_http_error(
            exc, status_code=422, detail="卖点填写内容有误，请检查后重试。"
        ) from exc
    except (TaxonomyError, sqlite3.IntegrityError) as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="卖点保存失败。请确认编号没有重复，然后刷新页面重试。",
        ) from exc


@router.patch("/api/v8/selling-points/items/{code}")
def update_v8_selling_point(
    request: Request, code: str, payload: SellingPointMutationRequest
) -> Dict[str, Any]:
    try:
        return update_point(
            code,
            payload.model_dump(),
            db_path=_request_config(request).db_path,
        )
    except TaxonomyValidationError as exc:
        raise _user_facing_http_error(
            exc, status_code=422, detail="卖点填写内容有误，请检查后重试。"
        ) from exc
    except (TaxonomyError, sqlite3.IntegrityError) as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="卖点保存失败，请刷新页面后重试。",
        ) from exc


@router.delete("/api/v8/selling-points/items/{code}")
def delete_v8_selling_point(request: Request, code: str) -> Dict[str, Any]:
    try:
        delete_point(code, db_path=_request_config(request).db_path)
    except TaxonomyValidationError as exc:
        raise _user_facing_http_error(
            exc, status_code=422, detail="这个卖点暂时无法删除，请刷新页面后重试。"
        ) from exc
    except TaxonomyError as exc:
        raise _user_facing_http_error(
            exc, status_code=409, detail="卖点删除失败，请刷新页面后重试。"
        ) from exc
    return {"code": code, "deleted": True}


@router.post("/api/v8/selling-points/publish")
def publish_v8_selling_points(request: Request) -> Dict[str, Any]:
    try:
        return publish_draft(db_path=_request_config(request).db_path)
    except TaxonomyError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="卖点标准发布失败，请检查草稿后重试。",
        ) from exc


@router.get("/api/v8/spu-audience/assets")
def get_v8_spu_audience_assets(request: Request) -> Dict[str, Any]:
    config = _request_config(request)
    try:
        return list_spu_audience_assets(
            db_path=config.db_path, read_only=config.read_only
        )
    except SpuAudienceError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="车型、人群和场景数据暂时无法读取，请刷新页面后重试。",
        ) from exc


@router.get("/api/v8/spu-audience/stats")
def get_v8_spu_audience_stats(
    request: Request, window: str = "all", platform: str = ""
) -> Dict[str, Any]:
    config = _request_config(request)
    if window not in STAT_WINDOWS:
        raise HTTPException(status_code=422, detail="所选统计时间无效，请刷新页面后重试。")
    if platform and platform not in STAT_PLATFORMS:
        raise HTTPException(status_code=422, detail="所选平台无效，请刷新页面后重试。")
    try:
        return _request_read_model(
            request,
            ("spu-audience-stats", window, platform),
            lambda: build_spu_audience_stats(
                db_path=config.db_path,
                window=window,
                platform=platform,
                read_only=config.read_only,
            ),
        )
    except SpuAudienceError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="统计数据暂时无法读取，请刷新页面后重试。",
        ) from exc


@router.post("/api/v8/spu-audience/associate")
def run_v8_spu_association(
    request: Request, background: BackgroundTasks, mode: str = "full"
) -> Dict[str, Any]:
    """启动后台刷新任务并立即返回；进度经 assets 接口的 last_run 轮询。

    mode=full 全量重算；mode=incremental 只补算上次成功刷新之后新增/重评估
    的 V2/V3 内容（页面打开时自动触发的就是增量），首次运行没有成功记录
    时增量自动升级为全量；mode=yesterday/this_week/last_week 只重算发布
    时间落在对应统计窗口内的 V2/V3 内容（页面「刷新数据」弹窗四选一）。
    """

    if mode not in {"full", "incremental", "yesterday", "this_week", "last_week"}:
        raise HTTPException(status_code=422, detail="所选刷新范围无效，请重新选择。")
    config = _request_config(request)
    since: Optional[str] = None
    scope_window: Optional[str] = None
    if mode == "incremental":
        with connect(config.db_path, read_only=config.read_only) as connection:
            since = resolve_incremental_since(connection)
    elif mode != "full":
        scope_window = mode
    try:
        run_id = start_association_run(db_path=config.db_path)
    except SpuAudienceError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=409,
            detail="当前无法开始刷新，请稍后重试。",
        ) from exc
    read_model_cache = getattr(request.app.state, "read_model_cache", None)
    background.add_task(
        _run_spu_association_job, config.db_path, run_id, since, scope_window,
        read_model_cache=(
            read_model_cache if isinstance(read_model_cache, ReadModelCache) else None
        ),
    )
    if since:
        resolved_mode = "incremental"
    elif scope_window:
        resolved_mode = f"window:{scope_window}"
    else:
        resolved_mode = "full"
    return {
        "run_id": run_id,
        "status": "running",
        "mode": resolved_mode,
    }


def _run_spu_association_job(
    db_path: Path,
    run_id: int,
    since: Optional[str] = None,
    scope_window: Optional[str] = None,
    read_model_cache: Optional[ReadModelCache] = None,
) -> None:
    """后台执行刷新；失败结论由 run_association 写回运行记录，这里补日志。

    规则链后自动挂 LLM 补空（B 链）：key 缺失时 hook 为 None，纯规则运行；
    LLM 阶段异常由 run_association 记入 summary_json.llm，不影响刷新状态。
    """

    try:
        run_spu_association(
            db_path=db_path, run_id=run_id, since=since,
            scope_window=scope_window,
            llm_hook=default_spu_llm_hook(),
        )
    except Exception:  # noqa: BLE001 —— 运行记录已标记 failed，仅记录堆栈
        LOGGER.exception("SPU 数据刷新后台任务失败 run_id=%s", run_id)
    finally:
        # Clear after completion so an interim poll cannot outlive the newly
        # committed associations.  Direct worker callers use the same path.
        if read_model_cache is not None:
            read_model_cache.clear()


@router.post("/api/v8/spu-audience/spu")
def upsert_v8_spu(request: Request, payload: SpuUpsertRequest) -> Dict[str, Any]:
    try:
        return upsert_spu(
            payload.model_dump(), db_path=_request_config(request).db_path
        )
    except SpuAudienceError as exc:
        raise _user_facing_http_error(
            exc,
            status_code=422,
            detail="车型填写内容有误，请检查后重试。",
        ) from exc


@router.get("/api/v7/history/reports")
def v7_history_reports(request: Request) -> Dict[str, Any]:
    with _legacy_connect(_request_config(request).legacy_db_path) as connection:
        rows = connection.execute(
            """
            SELECT rr.run_id, rr.revision, rr.created_at, rr.report_json_path,
                   rr.report_markdown_path, rr.summary_image_path, rr.output_sha256
            FROM report_revisions rr
            ORDER BY rr.created_at DESC, rr.run_id, rr.revision DESC
            """
        ).fetchall()
    return {
        "report_version": LEGACY_REPORT_VERSION,
        "revisions": [dict(row) for row in rows],
    }


@router.get("/api/v7/history/reports/{run_id}/revisions/{revision}")
def v7_history_report(request: Request, run_id: str, revision: int) -> Dict[str, Any]:
    with _legacy_connect(_request_config(request).legacy_db_path) as connection:
        row = connection.execute(
            "SELECT report_json_path FROM report_revisions WHERE run_id=? AND revision=?",
            (run_id, revision),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="历史报告不存在")
    return json.loads(
        _safe_project_path(str(row["report_json_path"])).read_text(encoding="utf-8")
    )


# Temporary read compatibility for the existing v7 frontend. These routes are removed at cutover.
@router.get("/api/health")
def legacy_health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "mode": "legacy_v7_read_only",
        "report_version": LEGACY_REPORT_VERSION,
    }


@router.get("/api/overview")
def legacy_overview(request: Request) -> Dict[str, Any]:
    return _legacy_overview(_request_config(request).legacy_db_path)


@router.get("/api/report/latest")
def legacy_latest_report(request: Request) -> Dict[str, Any]:
    return _legacy_report(_request_config(request).legacy_db_path)


@router.get("/api/runs")
def legacy_runs(request: Request) -> Dict[str, Any]:
    return {"runs": _legacy_runs(_request_config(request).legacy_db_path)}


@router.get("/api/runs/{run_id}")
def legacy_run(request: Request, run_id: str) -> Dict[str, Any]:
    value = _legacy_run(_request_config(request).legacy_db_path, run_id)
    if value is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    return value


@router.get("/api/runs/{run_id}/report")
def legacy_run_report(request: Request, run_id: str) -> Dict[str, Any]:
    value = _legacy_run(_request_config(request).legacy_db_path, run_id)
    if value is None or not value.get("output_path"):
        raise HTTPException(status_code=404, detail="任务报告不存在")
    return json.loads(
        _safe_project_path(str(value["output_path"])).read_text(encoding="utf-8")
    )


@router.get("/api/files/{file_key}")
def legacy_file(request: Request, file_key: str):
    filename = LEGACY_EXPORTS.get(unquote(file_key))
    if filename is None:
        raise HTTPException(status_code=404, detail="导出文件不存在")
    path = (
        _legacy_formal_report_path(_request_config(request).legacy_db_path).parent
        / filename
    )
    if not path.exists():
        raise HTTPException(status_code=404, detail="导出文件不存在")
    return FileResponse(path, filename=path.name)


@router.post("/api/inputs/validate")
def legacy_validate_inputs(payload: InputValidationRequest) -> Dict[str, Any]:
    return _validate_legacy_inputs(payload.channel, payload.text)


@router.post("/api/runs/{legacy_path:path}")
def reject_legacy_writes(legacy_path: str) -> JSONResponse:
    return JSONResponse(
        status_code=409,
        content={
            "error": "旧版页面已经停止修改，请使用当前页面操作。",
            "migration_target": "/api/v8",
            "legacy_path": f"/api/runs/{legacy_path}",
        },
    )


app = create_app()
